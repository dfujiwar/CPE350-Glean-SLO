<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>site registration</title>
<link href="gleanslo.css" rel="stylesheet" type="text/css" />
<script type="text/javascript">
function setFocus() { document.getElementById('farm').focus();}
function validateForm() {
   var x = document.forms["site_reg"]["contact1"].value;
    if (x=="" || x==null) { alert("Please enter the name of whom we can contact."); return false; }
   var x = document.forms["site_reg"]["phone1"].value;
    if (x=="" || x==null) { alert("Please enter a telephone number."); return false; }
}
</script>
<script src='https://www.google.com/recaptcha/api.js'></script>
</head>
<body class="SH" onload="setFocus()">
<div id="container">
  <div id="header">
   <img src="images/banners/logobanner1.png" width="876" height="180" border="2" /> 
  </div>
<div class="navdiv">
    <div class="navigation">
        <div class="spacer">&nbsp;</div>
        <ul>
            <li><a href="index.php"><strong>Home</strong></a></li>
        <li><a><label class="lab" for="tog1">About</label></a>
				<input type="checkbox" id="tog1"/>
                <ul class="dropped" id="menu1">
                <li><a href="mission.php">Mission&nbsp;&&nbsp;vision</a></li>
                <li><a href="team.php">Our&nbsp;team</a></li>
                <li><a href="history.php">History</a></li>
                <li><a href="how.php">How&nbsp;it&nbsp;works</a></li>
                <li><a href="annual.php">What&nbsp;we've&nbsp;done</a></li>
                <li><a href="FAQ.php">FAQ</a></li>
                <li><a href="contact.php">Contact&nbsp;us</a></li>
                <li><a href="employment.php">Employment</a></li>
                </ul>
            </li>
            <li><a href="volunteer.php"><strong>Volunteer</strong></a></li>
            <li><a href="site_registration.php"><strong>Donate&nbsp;crop</strong></a></li>
        <li><a><label class="lab" for="tog2">Support</label></a>
				<input type="checkbox" id="tog2"/>
                <ul class="dropped" id="menu2">
                <li><a href="https://domains.giveffect.com/campaigns/10230-gleanslo" target="_blank">Donate</a></li>
                <li><a href="wish.php">Wish&nbsp;list</a></li>
                <li><a href="supporters.php">Supporters</a></li>
                <li><a href="sponsorship.php">Sponsorship</a></li>
                <li><a href="vehicle.php">Donate a vehicle</a></li>
                </ul>
             </li>
            <li><a href="harvestlist.php"><strong>Harvests</strong></a></li>
        </ul>
        </div>
        </div>
<div class="clearfloat"></div>
<div id="mainContent">
<p> </p>
<div class="indentdiv">
    <h3 class="SH"><strong>Crop Donation Form</strong></h3>    
  <p>
 Thanks for thinking of GleanSLO and sharing your food with those in need! Please note that GleanSLO is a small, volunteer-powered organization with limited staff-time and harvesting resources- we are therefore unable to guarantee that we will be able to schedule a harvest with you, especially during busy seasons where we must prioritize properties with larger quantities of produce. See below for other options if GleanSLO is unable to schedule a harvest with you. Also note that for those harvests we are able to schedule, our equipment is limited and volunteers have limited abilities, so we cannot to guarantee that we will be able to harvest all the fruit you have to offer, but we will try our best! Thank you for being a part of the gleaning movement and sharing with our community!
 </p>
 <p>Have you donated to GleanSLO in the past but want to let  us know your crop is ready to pick this season?   You may already be registered! Please contact Program Coordinator  Emily Wilson, <a href="mailto:minman@slofoodbank.org">ewilson@slofoodbank.org</a> or (805) 235-1180, to arrange a glean.</p>
<p>All harvest participants will be trained in proper harvesting methods and sign waivers of liability that protect the crop owner as well as GleanSLO.</p>
<p>Privacy: Information entered here is used solely by GleanSLO and will not be available to the public. We do not share, sell or otherwise distribute your personal information. </p>
<p>If you have questions, please contact us at <a href="mailto:gleanslo@slofoodbank.org">gleanslo@slofoodbank.org</a>.</p>
<p><strong>In the case that GleanSLO is unable to help you share  your produce, consider the following alternatives:</strong></p>
If you are able to harvest the crops yourself...<br />
<blockquote>-Food can be dropped off to the SLO Food Bank warehouse or  another local partner agency near you! (contact the SLO Food Bank for locations  of nearby partner agencies)<br />
-Put out a basket of already&nbsp;harvested fruit for neighbors and passersby  to take for their own enjoyment!<br />
</blockquote>
If you are unable to harvest the crops yourself...<br />
<blockquote>-Place a sign in your yard for  passersby&nbsp;and neighbors to harvest what they would like from your tree(s)  or garden!</blockquote>
<hr style="width:80%;margin:auto;">
<br />
<form action="/site_registration.php?" id="site_reg" name="site_reg" method="post" onsubmit="return validateForm()">
<p>
        <label>Farm name or owner's last name
          <input name="farm" id="farm" type="text" value="" size="40"maxlength="60" />
</label>
</p>
      <p>
        <label>Contact person's name
          <input name="contact1" type="text" value="" size="40" maxlength="80" />
        </label>
      </p>
      <p>Phone
        number
        <label>
          <input name="phone1" type="text" value="" size="20" maxlength="50" />
        </label>
      Alternate phone number
        <label>
          <input name="phone2" type="text" value=""size="20" maxlength="50" />
        </label>
      </p>
      <p>Email address
        <input name="email1" type="text" value="" size="40" maxlength="60" />
      </p>
     <p>How best to reach me:
	<div style="margin-left:25px">
      <input name="howbest[]" type="checkbox" value="phone"/> Phone<br />
      <input name="howbest[]" type="checkbox" value="email"/> Email<br />
      <input name="howbest[]" type="checkbox" value="text"/> Text message<br />
      <input name="howbest[]" type="text" value="" maxlength="30" size="15"/> Other</p>
</div>
      <p>
        <label>Address of the crop
          <input name="address" type="text" value="" size="50" maxlength="80" />
        </label>
		</p>
        <p>
		<label>City <input name="city" type="text" value="" size="30" maxlength="30" /></label>
        <label>State <input name="state" type="text" value="" size="2" maxlength="2" /></label>
        <label>Zip <input name="zip" type="text" value="" size="5" maxlength="5" /></label>
        </p>
        <p>
     <label>Mailing address (if different from crop address)
          <input name="maddress" type="text"value="" size="60" maxlength="80" />
        </label>
      </p>
        <p><label>City <input name="mcity" type="text" value="" size="30" maxlength="30" /></label>
        <label>State <input name="mstate" type="text" value="" size="2" maxlength="2" /></label>
        <label>Zip <input name="mzip" type="text" value="" size="5" maxlength="5" /></label>
        </p>
       <p>What is your relationship to this property?</p>
      <p  id="indent">
        <label>
		<input name="property_rel" type="radio" id="property_rel_0" value="owner" checked="checked" />
Owner and occupant</label>
        <br />
        <label>
          <input type="radio" name="property_rel" value="landlord" id="property_rel_1" />
          Rental property (landlord)</label>
        <br />
        <label>
          <input type="radio" name="property_rel" value="renter" id="property_rel_2" />
          Renter</label>
        <br />
        <label>
          <input type="radio" name="property_rel" value="other" id="property_rel_3" />
          Other</label>
          <br />
        <label>Landlord contact information (if applicable)
          <input type="text" name="landlord" size="40" id="landlord" value=""/>
        </label>
      </p>
<p>
      <label>What type of site?
          <select name="venue" >
            <option value=" " selected="selected">[select]</option>
            <option value="Backyard">Backyard</option>
            <option value="Farm">Commercial farm</option>
            <option value="Drive">Fruit drive</option>
            <option value="Pickup">Small amount to pick up</option>
            <option value="Market">Market</option>
            <option value="Event">Event</option>
          </select>
      </label>  </p>
<p>
<label>What type(s) of produce?
          <input name="crops" type="text" id="crops" value=""size="100" maxlength="150" />
 </label>
<br />
Currently, as a program of the SLO Food Bank, GleanSLO  harvests according to storage and distribution capacity of the food bank and  its partner agencies. <strong>We do not currently harvest loquats, wine grapes, olives, or  any type of nuts</strong>&nbsp;due to either very short shelf life, need for  processing, lack of demand, or potential allergy issues.</p>
      <p>How much (for instance '2 trees' or '3 acres' or '300 pounds')
        <input name="size" type="text" id="size" value=""size="30" maxlength="30" />
</p>
      <p>Location of plants on the property
        <input name="location" type="text" id="location" size="30" value="" maxlength="20" />      
      <p>Crop height (feet)
      <input name="height" type="text" id="height" size="5" value=""maxlength="10" />      
      <p>Lowest produce height (feet)
        <input name="lowest" type="text" id="lowest" size="5" value="" maxlength="10" /> </p> 
       <p>Does the crop have any fungus, disease or pest issues?</p>
      <p id="indent">
        <label><input name="disease" type="radio" id="disease_0" value="No" checked="checked" /> No</label>&nbsp;&nbsp;&nbsp;
        <label><input type="radio" name="disease" value="Yes" id="disease_1" /> Yes </label><br />
        <label>Describe <input name="disease_text" type="text" id="disease_text" value=""size="25" maxlength="25" />
        </label></p>
        <p>Which chemicals or supplements, if any, are used on or around the crop area that GleanSLO's more sensitive or iimmuno-suppressed volunteers should be aware of?<br />
         <input name="spray_text" type="text" id="spray_text" value=""size="80" maxlength="100" /></p>
      <p>
       What time of year is the crop usually ripe?
          <select name="month_ripe" id="when_ripe">
            <option value="01" selected="selected">[month]</option>
            <option value="01">January</option>
            <option value="02">February</option>
            <option value="03">March</option>
            <option value="04">April</option>
            <option value="05">May</option>
            <option value="06">June</option>
            <option value="07">July</option>
            <option value="08">August</option>
            <option value="09">September</option>
            <option value="10">October</option>
            <option value="11">November</option>
            <option value="12">December</option>
      </select>
          <select name="week_ripe" id="when_ripe">
            <option value="01" selected="selected">[week]</option>
            <option value="03">first week</option>
            <option value="10">second week</option>
            <option value="17">third week</option>
            <option value="24">fourth week</option>
      </select></p>
      <p>Is there anything else you would like us to know (condition of the produce, access to the crops, preferred ways and times to contact you )?</p>
      <p>
        <label>
          <textarea name="otherinfo" cols="80" rows="3"></textarea>
        </label></p>
       <p>I would like my donation to be acknowledged:</p>
      <p id="indent">
        <label>
		<input name="recog" type="radio" value="Yes" checked="checked" /> Yes</label>&nbsp;&nbsp;&nbsp;
        <label><input type="radio" name="recog" value="No" /> No </label><br />
        <label>Acknowledge my donation as coming from: <input name="recog_text" type="text" value=""size="40" maxlength="60" />
        </label></p>
        <p><label>How did you hear about GleanSLO?
          <select name="howhear" id="howhear">
            <option value=" " selected="selected">[select]</option>
            <option value="Neighbor">Neighbor</option>
            <option value="GleanSLO web site">GleanSLO Web Site</option>
            <option value="SLO Food Bank">SLO Food Bank</option>
            <option value="GleanSLO volunteer">GleanSLO volunteer</option>
            <option value="Newspaper">Newspaper</option>
            <option value="Facebook">Facebook</option>
            <option value="Flyer">Flyer</option>
            <option value="Craigslist">Craigslist</option>
            <option value="Other urban harvesting group">Other urban harvesting group</option>
            <option value="Friend">Friend</option>
            <option value="Other">Other</option>
            <option value="Web search">Web search</option>
          </select>
      </label></p> 
<div class="g-recaptcha" data-sitekey="6LfTB0sUAAAAABJ1NkgZTZH0JYEMrdGDKqqy9kT3"></div><!-- This key is attached to the dyates@gleanweb.org Google account -->      <p>
        <label>
        <input class="button"  style="font-weight:bold;" type="submit" name="submit" id="submit" value="Save" />
      </label>
        <input type="hidden" name="MM_insert" value="site_reg" /></p>
</form>
    </div>
<!-- end #mainContent --></div>
<br class="clearfloat" />
<!--<div id="footer">
<div style="float:right; width:170;"><a href="http://www.gleanweb.org" target="_blank"><img src="images/Nav buttons/gleanweb.png" alt="Website by GleanWeb" height="20" /></a></div>
<div style="width:700; "><center>Copyright © 2020 GleanSLO</center></div>
</div>-->
<div id="footer">
<div style="float:right; width:25%;text-align:right;"><a href="http://www.gleanweb.org" target="_blank"><img src="images/Nav buttons/gleanweb.png" alt="Website by GleanWeb" style="max-height:20px;" /></a></div>
<div style="float:right;width:35%;text-align:center;" id="google_translate_element"></div>
<script type="text/javascript">
function googleTranslateElementInit() { new google.translate.TranslateElement({pageLanguage: 'en', includedLanguages: 'es,en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element'); }
</script>
<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
<div style="width:39%; "><center>Copyright © 2020 GleanSLO</center></div>
</div>
<!-- end #container --></div>
</body>
</html>
