<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Awards and Recognition</title>
<link href="gleanslo.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
-->
</style>
</head>
<body class="SH">
<div id="container">
  <div id="header">
   <img src="images/banners/logobanner1.png" width="876" height="180" border="2" /> 
  </div>
<div class="navdiv">
    <div class="navigation">
        <div class="spacer">&nbsp;</div>
        <ul>
            <li><a href="index.php"><strong>Home</strong></a></li>
        <li><a><label class="lab" for="tog1">About</label></a>
				<input type="checkbox" id="tog1"/>
                <ul class="dropped" id="menu1">
                <li><a href="mission.php">Mission&nbsp;&&nbsp;vision</a></li>
                <li><a href="team.php">Our&nbsp;team</a></li>
                <li><a href="history.php">History</a></li>
                <li><a href="how.php">How&nbsp;it&nbsp;works</a></li>
                <li><a href="annual.php">What&nbsp;we've&nbsp;done</a></li>
                <li><a href="FAQ.php">FAQ</a></li>
                <li><a href="contact.php">Contact&nbsp;us</a></li>
                <li><a href="employment.php">Employment</a></li>
                </ul>
            </li>
            <li><a href="volunteer.php"><strong>Volunteer</strong></a></li>
            <li><a href="site_registration.php"><strong>Donate&nbsp;crop</strong></a></li>
        <li><a><label class="lab" for="tog2">Support</label></a>
				<input type="checkbox" id="tog2"/>
                <ul class="dropped" id="menu2">
                <li><a href="https://domains.giveffect.com/campaigns/10230-gleanslo" target="_blank">Donate</a></li>
                <li><a href="wish.php">Wish&nbsp;list</a></li>
                <li><a href="supporters.php">Supporters</a></li>
                <li><a href="sponsorship.php">Sponsorship</a></li>
                <li><a href="vehicle.php">Donate a vehicle</a></li>
                </ul>
             </li>
            <li><a href="harvestlist.php"><strong>Harvests</strong></a></li>
        </ul>
        </div>
        </div>
<div class="clearfloat"></div>
<div id="mainContent">
 <div id="narrowbody">
<p><img src="images/logos/logo-small.png" width="230"/></p>
<h3>Awards and Recognition</h3>
<p><strong>2018</strong></p>

<p><em>Truck Mandate</em>, KSBY, <a href="http://www.ksby.com/story/38188843/food-banks-struggle-to-receive-produce-under-new-trucking-mandates">news story</a>, May 14,2018</p>


<p><em>Wine, Waves Beyond</em>, KSBY, <a href="http://www.ksby.com/story/38133172/wine-waves-and-beyond-event-raises-money-for-gleanslo">news story</a>, May 7,2018</p>


<p><em>Wine, Waves Beyond</em>, KCOY, <a href="https://www.keyt.com/lifestyle/central-coast-lifestyle-to-be-celebrated-this-weekend-at-wine-waves-and-beyond/738400019">news story</a>, May 3, 2018</p>

<em>Wine, Waves Beyond</em>, KSBY, <a href="http://www.ksby.com/story/38124751/wine-waves-and-beyond-event-raises-money-to-combat-hunger">news story</a>, May 3, 2018</p>


<p><em>Wine, Waves Beyond</em>, New Times, <a href="https://www.newtimesslo.com/sanluisobispo/wine-waves-and-beyond-hits-pismo-may-4-6/Content?oid=4993216">news story</a>, May 3, 2018</p>

<p><em>Nourishing</em>, New Times, <a href="https://www.newtimesslo.com/sanluisobispo/nourishing/Content?oid=4825591">news story</a>, April 18,2018</p>


<p><strong>2017</strong></p>

<p><em>Cal Poly Students, provide fall bounty for GleanSLO</em>, KSBY, <a href="https://calpolynews.calpoly.edu/cpreport/2017/nov_15">news story</a>, November 15, 2017</p>

<p><em>Farmers, volunteers collect surplus produce to give to the hungry</em>, KSBY, <a href="http://www.ksby.com/story/36603876/farmers-volunteers-collect-surplus-produce-to-give-to-the-hungry">news story</a>, October 16, 2017</p>

<p><em>GleanSLO harvests to allay hunger</em>, KCBX, <a href="http://kcbx.org/post/glean-slo-harvests-allay-hunger#stream/0">news story</a>, October 9, 2017</p>


<p><em>Sign up to pick a bumper crop</em>, New Times, <a href="https://www.newtimesslo.com/sanluisobispo/good-stuff/Content?oid=3103132">news story</a>, June 29, 2017</p>

<p><em>GleanSLO partners with UC Master Gardeners</em>, blog, <a href="http://ucanr.edu/blogs/blogcore/postdetail.cfm?postnum=24312">news story</a>, June 7, 2017</p>


<p><em>GleanSLO rescuing local produce</em>, KEYT, <a href="http://www.keyt.com/news/agriculture/gleanslo-rescuing-local-produce-to-help-feed-people-in-need/523065579">news story</a>, May 30, 2017</p>

<p><em>Rabobank donates $10,000</em>, Tribune, <a href="http://www.sanluisobispo.com/news/local/community/article151558332.html">news story</a>, May 19, 2017</p>

<p><em>Interview with SLO Clean Air</em>,<a href="https://slocleanair.podbean.com/e/slo-county-program-spotlight-gleanslo/"> podcast</a>, May 09, 2017</p>

<p><em>Feeding America Food Rescue</em>,<a href="https://www.youtube.com/watch?v=IAUqBh4jaxU"> video</a>, April 21st, 2017</p>

<p><em>Niner Wine Estates Donates $11,400 </em>, PR Newswire, <a href="http://www.prnewswire.com/news-releases/niner-wine-estates-donates-22050-to-local-charities-300386114.html">news story</a>, January 05, 2017</p>

<p><strong>2016</strong></p>

<p><em>GleanSLO donates 1 million pounds</em>, Tribune, <a href="http://www.sanluisobispo.com/news/local/community/article122058564.html">news story</a>, December 20, 2016</p>

<p><em>SLO Food Bank to offer more fresh produce thanks to major grant</em>, <a href="http://www.ksby.com/story/32946376/slo-food-bank-to-offer-more-fresh-produce-thanks-to-major-grant">news story</a>, KSBY, September 1st, 2016</p>

<p><em>Wine Waves & Beyond Gives Back</em>, Coast News, <a href="http://www.gleanslo.org/documents/CheckPresentationArticle.pdf">news story</a>, August 25, 2016</p>

<p><em>Ugly Food Month at Bethel Lutheran Church seeks to stem the tide of food waste</em>, <a href="http://www.newtimesslo.com/strokes-and-plugs/14156/ugly-food-month-at-bethel-lutheran-church-seeks-to-stem-the-tide-of-food-waste/">news story</a>, New Times, August 3rd, 2016</p>

<p><em>Giving Back to the Community at the Downtown SLO Farmers' Market,</em> <a href="http://tolosapressnews.com/giving-back-community-downtown-slo-farmers-market/">news story</a>, Tolosa Press, June 2, 2016</p>

<p><em>Good News for GleanSLO...</em>, <a href="http://www.sanluisobispo.com/news/local/community/article80340537.html">news story</a>, SLO Tribune, May 27, 2016</p>

<p><em>Senior Farmers Market supplies seniors with fresh produce, </em><a href="http://www.ksby.com/story/32056737/senior-farmers-market-supplies-seniors-with-fresh-produce">article</a> by Katherine Worsham, KSBY, May 24, 2016</p>

<p><em>Barrel to Barrel Benefits GleanSLO</em>, <a href="http://tolosapressnews.com/barrel-barrel-benefits-glean-slo/">news story</a>, Tolosa Press, May 4, 2016</p>

<p><em>Volunteers Harvest Food for Needy Families Through Glean SLO Program</em>, <a href="http://www.keyt.com/news/Volunteers-Harvest-Food-for-Needy-Families-Through-Glean-SLO-Program/39152596">television news story</a>, Dave Alley, KEYT - KCOY - KKFX Reporter, April 21, 2016</p>

<p><em>GleanSLO: Reclaiming the county's forgotten produce, one pick at a time</em>, <a href="http://www.newtimesslo.com/food-wine/13555/gleanslo-reclaiming-the-countys-forgotten-produce-one-pick--at-a-time/">article</a> by Hayley Thomas, New Times SLO, March 16, 2016</p>

<p><strong>2015</strong></p>

<p>
<span style="font-family:arial,helvetica,sans-serif;"><em>Local Farming Company Helps Give Food to Families in Need</em>, <a href="http://www.ksby.com/story/30338421/local-farming-company-helps-give-food-to-families-in-need">News Story</a> by KSBY, October 24, 2015</p>

<p>
<span style="font-family:arial,helvetica,sans-serif;"><em>Food for thought: It doesn't take much to help hungry in Cambria</em>, <a href="http://www.sanluisobispo.com/2015/06/03/3662963_food-bank-donation-hunger.html?rh=1">The Cambrian</a>, Dianne Brooke, June 3, 2015</span>
</p>

<p><span style="font-family:arial,helvetica,sans-serif;"><em>Trabia Farms opens sensory garden, exploratorium</em>, <a href="http://pasoroblesdailynews.com/trabia-farms-opens-sensory-garden-exploratorium/34463/">Paso Robles Daily News</a>, Heather Young, April 22, 2015</span></p>
		<p>

<em>Waste not, want not: GleanSLO turns leftover produce into meals in the making</em>, <a href="documents/NTgleanslo.pdf">New Times SLO</a>, Jono Kinkade, January 2015</span></p>

<p><strong>2014</strong></p>

<em style="font-family: Arial, Helvetica, sans-serif; font-size: 16px;">Good News!</em><span style="font-family: Arial, Helvetica, sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);"> </span><a href="https://www.facebook.com/gleanslo/photos/pb.290283964316368.-2207520000.1420751591./931311886880236/?type=3&theater" style="color: rgb(28, 63, 149); text-decoration: none; font-family: Arial, Helvetica, sans-serif; font-size: 16px;" target="_blank">photograph</a><span style="font-family: Arial, Helvetica, sans-serif; font-size: 16px; background-color: rgb(255, 255, 255);"> of Niner Wine Estates donating $6,300 to GleanSLO, San Luis Obispo Tribune, December 4, 2014</span></p>
		<p>

<span style="font-family:arial,helvetica,sans-serif;"><em>GleanSLO: A step toward a better society</em>, <a href="http://ageagletimes.com/1389/features/gleanslo-a-step-toward-a-better-society/">article</a>, The Eagle Times-Arroyo Grande High School News, by Annika Mancini, November 19, 2014</span></p>
		<p>

<span style="font-family:arial,helvetica,sans-serif;"><em>Gathering for Good No Crop Left Behind</em>, <a href="https://www.facebook.com/gleanslo/photos/pb.290283964316368.-2207520000.1420752228./933604809984277/?type=3&theater">article</a>, San Luis Obispo County Farm Bureau Magazine, Commemorative Issue, by Katy Budge, November 2014</span></p>
		<p>
			<span style="font-family:arial,helvetica,sans-serif;"><span style="font-size:16px;"><em>Squeezed by drought, farmer donates avocado harvest to the hungry</em>, <a href="http://www.sanluisobispo.com/2014/07/22/3163404/gleanslo-avocado-farmer-food-bank.html?">article</a>, San Luis Obispo Tribune by Kaytlyn Leslie, July 22, 2014</span></span></p>
		<p>
			<em>GleanSLO helps savage crops that would otherwise go to waste due to drought</em>, <a href="http://www.ksby.com/news/glean-slo-helps-salvage-crops-that-would-otherwise-go-to-waste-due-to-drought/">news story</a> on KSBY News by Olivia DeGennaro, July 19, 2014 </p>

			<em>SLO saves drought stricken avocados</em>, <a href="http://www.keyt.com/news/slo-saves-drought-stricken-avocados/27046988">news story</a> by KEYT - KCOY - KKFX News by Nataly Tavidian, July 19, 2014</p>

			<em>Glean to Give</em>, <a href="http://issuu.com/brockcenter/docs/agcirclespring2014-issuu#">article</a> by Diana Melero in Cal Poly University Ag Circle Magazine, page 20-21, Spring 2014 edition</p>
	</body>
</html>
<p><em>GleanSLO Wants Your Excess Fruits and Vegetables</em>, <a href="http://www.ksby.com/news/glean-slo-wants-your-excess-fruits-and-vegetables/" target="_blank">news story</a> on KSBY News by Connie Tran, May 16, 2014, <a href="images/KSBY article.png" target="_blank">article</a><p>
<p><em>GleanSLO volunteers keep crops from going to waste</em>, <a href="http://www.sanluisobispo.com/2014/03/26/2991877/gleanslo-volunteers-keep-crops.html?sp=/99/151/">article</a>, San Luis Obispo Tribune by Katy Budge, March 26, 2014</p> 

<p><em>Saving Fruit in SLO</em>, <a href="images/KCOY3-8-14.png" target="_blank">news story</a> on KCOY Central Coast News by Nataly Tavidian, March 8, 2014</p>
<p>$446 Award from Promega Bioscience <a href="images/Tribune3-6-14.png" target="_blank">photograph</a> Corporate matching funds from the Promega Produce Swap! March 2014 </p>
<p><em>Backyard Bounty to Feed Hungry</em>, <a href="images/SLOCityNews3-6-14.png" target="_blank">article</a> Page 13 in SLO City News by Theresa-Marie Wilson, March 2014</p>
<p><em>Fruit Falling</em> <a href="images/NewTimes3-6-14.png" target="_blank">article</a>, New Times by Trever Dias, March 6, 2014</p>
<p><em>Good News!</em> <a href="images/Tribune3-6-14.png" target="_blank">photograph</a>, Evan Jenkins donating produce from his Fruit Drive, San Luis Obispo Tribune, March 6, 2014</p>
<p><em>Meet GleanSLO</em>, <a href="http://www.q1045fm.com/up-n-adam/?p=6903">Radio Interview</a>, Q104.5 Radio-Up and Adam in the Morning, March 7, 2014</p>
<p><em>Gearing up to Glean</em>, <a href="http://northcountyfarmersmarkets.com/Newsletters/v3n2_feb2014.htm">article</a>, North County Farmers' Market Newsletter, February 2014</p>
<p><em>GleanSLO</em>, <a href="http://slocoastjournal.com/docs/onecoolearth.html">article</a>, SLO Coast Journal by Greg Ellis, January 2014</p>
<p><strong>2013</strong></p>
<p><em>Harvesting apples for the Food Bank, </em><a href="http://www.sanluisobispo.com/2013/09/23/2697884/harvesting-apples-for-the-food.html">article</a>, San Luis Obispo Tribune by David Middlecamp, September 21, 2013</p>
<p><em>Community Foundation San Luis Obispo awards $3,400 to GleanSLO, </em><a href="http://www.sanluisobispo.com/2012/02/24/1961381/good-news.html">photograph</a>, San Luis Obispo Tribune, September 21, 2013</p>
<p><em>GleanSLO rescues food, feeds the hungry, </em><a href="documents/Atascadero2013-07-19.pdf">article</a>, Atascadero News by Creig P. Sherburne, July 19, 2013</p>
<p>Central San Joaquin Valley gleaning programs see resurgence,  <a href="http://www.fresnobee.com/2013/07/19/3396253/central-san-joaquin-valley-gleaning.html">article</a>, Fresno Bee, July  19, 2013</p>
<p>SARP/NCWS Staff Give Back with GleanSLO,  <a href="http://slo.edhat.com/site/tidbit.cfm?nid=115723&nc=1">article</a>, on Edhat, June  6, 2013</p>
<p>Más de 1,000 voluntarios en la Costa Central espigan  productos agricolas y luego se los donan a los necesitados article [<a href="http://santamariatimes.com/espanol/noticias/local/m-s-de-voluntarios-en-la-costa-central-espigan-productos/article_a65bf82c-753e-11e2-88be-0019bb2963f4.html" target="_blank">Spanish</a>] [<a href="http://santamariatimes.com/news/local/more-than-central-coast-volunteers-pick-produce-then-donate-it/article_979d5362-7412-11e2-b3a2-001a4bcf887a.html" target="_blank">English</a>], Santa Maria Times by Jennifer Best, February 11, 2013</p>
<p><em>GleanSLO Helps Feed the Hungry</em>, <a href="http://www.kcoy.com/category/187903/video-page?autoStart=true&topVideoCatNo=default&clipId=8759149" target="_blank">news video</a>, KCOY television, April 2013</p>
<p><em>Gleaning the County's Bounty for the County's Hungry</em>, <a href="http://casafestiva.wordpress.com/2013/04/03/gleaning-the-countys-bounty-for-the-countys-hungry/" target="_blank">article</a>, Casa Festiva website by Katy Budge, April 3, 2013</p>
<p><em>Two tons of Hearst Castle oranges to go to the needy,</em> <a href="http://www.sanluisobispo.com/2013/03/12/2426767/two-tons-of-hearst-castle-oranges.html" target="_blank">article</a>, San Luis Obispo Tribune by Kathe Tanner, March 13, 2013</p>
<p>  <em>Backyard Fruit</em>, <a href="http://www.sanluisobispo.com/2013/02/21/2401443/backyard-fruit.html" target="_blank">letter to  the editor</a> in the San Luis Obispo Tribune by Jahan Ramezani, February 21, 2013</p>
<p>  <em>More than 1,000 Central Coast volunteers pick produce, then  donate it to needy</em>, <a href="http://santamariatimes.com/news/local/more-than-central-coast-volunteers-pick-produce-then-donate-it/article_979d5362-7412-11e2-b3a2-001a4bcf887a.html" target="_blank">article</a>, Santa Maria Times by Jennifer Best, February  11, 2013</p>
<p>  <em>GleanSLO</em>, <a href="http://digitaleditions.sheridan.com/publication/?i=141014&p=7" target="_blank">article</a>, Edible San Luis Obispo by Greg Ellis, February 2013</p>
<p>  $768 Award from The Cliffs Resort & Marisol's Karmic Pizza event, January 2013<br />
  </p>
<p><strong>2012</strong></p>
<p>  <em>Within Reach...</em>, <a href="http://www.slofarmbureau.org/pdf/SLO%20Country%20Magazine/Winter%202011-12%20SLO%20Country.pdf" target="_blank">article</a>, San Luis Obispo Country Magazine Volume 40 Issue 4, Winter 2011-2012</p>

<p>  <em>Good News!</em> <a href="documents/Good news-gleanSLO - Nov 29, 2012, 10-24 AM.pdf" target="_blank">photograph</a> of Congregation Ohr Tzafon donating to the Food Bank, San Luis Obispo Tribune, November 29, 2012</p>
<p>  <em>Good News!</em> <a href="documents/GleanSLO good news - Nov 14, 2012, 9-23 AM.pdf" target="_blank">photograph</a> of GleanSLO and Mission Prep High School Students, San Luis Obispo Tribune, November 14, 2012</p>
<p>  $1,000 Award from the Rotary Club of San Luis Obispo, May 2012</p>
<p>  $1,000 Award from Rotary Club of San Luis Obispo Daybreak, March 2012</p>
<p>  <em>Good Clean fun: Harvesting in SLO</em>,  <a href="http://www.bambubatu.com/blog/2012/01/01/good-glean-fun-harvesting-in-slo/" target="_blank">article</a>, Bambu Batu Newsletter by Momatus, January 1, 2012</p>
<p>  <strong>2011</strong></p>
<p><em>Chew on this</em>, <a href="http://www.newtimesslo.com/cover/7093/chew-on-this/" target="_blank">article</a>, New Times by Kathy Johnston, December 21, 2011 </p>
<p>  <em>Keeping it Fresh</em>, on KCBX Public Radio Chef/Host Charles Myers <a href="http://kcbx.org/mp3archive/kif111207.mp3" target="_blank">interviews</a> Carl Hansen, executive  director of the Food Bank Coalition, then goes to glean apples with GleanSLO.  December 2011</p>
<p>  Recipient of Unitarian Universalist Fellowship of San Luis  Obispo County's Community Outreach Offering- For making a real difference in  our community, especially in the lives of those who don't always have healthy,  fresh food to eat...[and] continuing to increase food security and decrease  agricultural waste in our county. December 2011</p>
<p><em>Bouquets and Brickbats: SLO can handle own affairs</em>, thanks,  Editorial in the San Luis Obispo Tribune, October 27, 2011</p>
<p><em>Gleaning Meeting</em>, <a href="http://slo.edhat.com/site/tidbit.cfm?id=1476&nid=71507">press release</a> published online October 24, 2011</p>
<p>  <em>For GleanSLO, no food is left behind</em>, <a href="http://www.sanluisobispo.com/2011/10/23/1808013/for-gleanslo-no-food-is-left-behind.html" target="_blank">article</a>, San Luis Obispo Tribune by Julia Hickey, October 23, 2011</p>
<p>  <em>Gleaning Possibilities</em>, <a href="http://208.76.83.134/~twpalygj/documents/GleaningArticle-Leaflet.pdf" target="_blank">article </a>in The Leaflet-California Rare Fruit Grower's  Newsletter by Carolyn Eicher, January-February 2011</p>
<p>  Recipient of 2010-2011 Innovation Award from United Way of  San Luis Obispo County- Recognized a local non-profit organization for creative  approaches and programs that provide value to the SLO County community in areas  of education, income and health.</p>
<p>  <strong>2010</strong></p>
<p>  Backyard Harvest's <a href="documents/slo byh brochure-2.jpg" target="_blank">flyer</a> for the first Community Fruit  Collection with California Rare Fruit Growers sponsored by SLO Grown Kids,  February 2010</p>
<p>  <em>Backyard Harvest Chapter Gains New Momentum</em>, <a href="documents/Edible SLO 2010 - Mar 7, 2013, 12-42 PM.pdf" target="_blank">article </a>, Edible San Luis Obispo by Katy Budge, Spring 2010</p>
<p>  <em>Giving, Donating and Supporting Part I</em>, <a href="documents/Fruit Gardener Magazine_CRFG.pdf" target="_blank">article </a>in Fruit Gardener- California Rare Fruit Growers by Joe Sabol, November & December  2010</p>
<p> </p> 
 </div>
<p><br />
</p>
 <!-- end #mainContent --></div>
<!-- This clearing element should immediately follow the #mainContent div in order to force the #container div to contain all child floats --><br class="clearfloat" />
<!--<div id="footer">
<div style="float:right; width:170;"><a href="http://www.gleanweb.org" target="_blank"><img src="images/Nav buttons/gleanweb.png" alt="Website by GleanWeb" height="20" /></a></div>
<div style="width:700; "><center>Copyright © 2020 GleanSLO</center></div>
</div>-->
<div id="footer">
<div style="float:right; width:25%;text-align:right;"><a href="http://www.gleanweb.org" target="_blank"><img src="images/Nav buttons/gleanweb.png" alt="Website by GleanWeb" style="max-height:20px;" /></a></div>
<div style="float:right;width:35%;text-align:center;" id="google_translate_element"></div>
<script type="text/javascript">
function googleTranslateElementInit() { new google.translate.TranslateElement({pageLanguage: 'en', includedLanguages: 'es,en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element'); }
</script>
<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
<div style="width:39%; "><center>Copyright © 2020 GleanSLO</center></div>
</div>
<!-- end #container --></div>
</body>
</html>
