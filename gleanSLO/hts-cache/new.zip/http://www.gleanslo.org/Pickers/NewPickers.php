<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>New volunteers</title>
<link href="../gleanslo.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
tr { background-color: #d2e2f7; }
-->
</style>
</head>
<body class="SH">
<div id="container">
<div id="header"><img src="../images/banners/logobanner1.png" width="876" height="180" border="2" /></div>
<div class="navdiv">
    <div class="navigation">
        <div class="spacer">&nbsp;</div>
        <ul>
            <li><a href="../index.php"><strong>Home</strong></a></li>
        <li><a><label class="lab" for="tog1">About</label></a>
				<input type="checkbox" id="tog1"/>
                <ul class="dropped" id="menu1">
                <li><a href="../mission.php">Mission&nbsp;&&nbsp;vision</a></li>
                <li><a href="../team.php">Our&nbsp;team</a></li>
                <li><a href="../history.php">History</a></li>
                <li><a href="../how.php">How&nbsp;it&nbsp;works</a></li>
                <li><a href="../annual.php">What&nbsp;we've&nbsp;done</a></li>
                <li><a href="../FAQ.php">FAQ</a></li>
                <li><a href="../contact.php">Contact&nbsp;us</a></li>
                <li><a href="../employment.php">Employment</a></li>
                </ul>
            </li>
            <li><a href="../volunteer.php"><strong>Volunteer</strong></a></li>
            <li><a href="../site_registration.php"><strong>Donate&nbsp;crop</strong></a></li>
        <li><a><label class="lab" for="tog2">Support</label></a>
				<input type="checkbox" id="tog2"/>
                <ul class="dropped" id="menu2">
                <li><a href="https://domains.giveffect.com/campaigns/10230-gleanslo" target="_blank">Donate</a></li>
                <li><a href="../wish.php">Wish&nbsp;list</a></li>
                <li><a href="../supporters.php">Supporters</a></li>
                <li><a href="../sponsorship.php">Sponsorship</a></li>
                <li><a href="../vehicle.php">Donate a vehicle</a></li>                </ul>
             </li>
            <li><a href="../harvestlist.php"><strong>Harvests</strong></a></li>
        </ul>
        </div>
	</div>
<div class="clearfloat"></div>
<div id="mainContent">
    </p><h3><strong><center>
      Information for New Volunteers
    </center></strong></h3>
    <p>Thank you for registering as a volunteer with GleanSLO! We look forward to meeting you. By volunteering with GleanSLO, you are agreeing to the <a href="ParticipationTerms.php"  target="_blank">Terms of Participation</a>. Here is other helpful  information.<br />
    </p>
    <p><strong>First, registration</strong> <br />
    </p>
    <p>Everyone who attends a harvest must  first be registered as a volunteer. Once you are registered, you are eligible to  sign up for harvests, and you don’t have to register again. If you have not signed up for a harvest for 14 months you will no longer be sent emails announcing large harvests. You can go to the <a href="../volunteer.php"  target="_blank">Volunteer</a> page to renew your registration.</p>
    <p><strong>Find out about harvests</strong> <br />
    </p>
    <p>For large harvests, we will send an  email with a description of the harvest and a link to the <a href="../harvestlist.php"  target="_blank">Harvests</a> page.</p>
    <p>      An email is not sent for smaller  harvests, but they are posted on the <a href="../harvestlist.php"  target="_blank">Harvests</a> page. Often, we find out  about crop donations on very short notice, so check your email or the Harvests page regularly. </p>
    <p><strong>Sign up for a harvest</strong> <br />
    </p>
    <p>Open harvests are posted on the Harvests page. To sign up, click on the harvest link, and then type in your name.  You must type it exactly as you did when you first registered, so we can match  your record in our database.<br />
    </p>
    <p>You must read and check off the Release  and Waiver to be added to the roster. Then click on the button that says  ‘Signup for this harvest.’<br />
    </p>
    <p><strong>How will I know where the harvest is?</strong> <br />
  </p>
    <p>After you sign up, you’ll see a page  with the address of the harvest and helpful information, such as whether a  ladder is needed. This is the only place the actual address appears on the website  so write it down or print it out. <br />
    </p>
    <p>You’ll also receive an email with the  same information and a link back to that web page. If you want to check out  your history of participation or have the email resent, go to the “Volunteer”  button on our <a href="../index.php"  target="_blank">homepage</a>.</p>
    <p><strong>Please cancel if you can’t make it!</strong> <br />
    </p>
    <p>If your schedule changes, please cancel  so someone else can take your spot. The email you receive will include a link where  you can cancel. Your courtesy will also help us schedule the right number of  volunteers for the available produce. <br />
    </p>
    <p><strong>When you arrive …</strong> <br />
    </p>
    <p>When you arrive GleanSLO volunteers  will show you where to park and help you check in. We’ll provide a brief  orientation with helpful tips and information about the property.</p>
 <p>Every adult who attends a harvest must  be a registered volunteer and must have signed up online for that harvest.  Children do not need to register or sign up, but must be supervised by an adult  who is on the roster. Please note that not all harvests allow children. We will post specific information when harvests are child-friendly.<br />
    </p>
    <p>That is all the basic information!  Please keep reading to find answers to questions that volunteers often have about  GleanSLO.<br />
    </p>
    <p><strong>Who runs GleanSLO?</strong> <br />
</p>
    <p>GleanSLO is an effort under the Food Bank Coalition of   San Luis Obispo County that unites  farmers, community volunteers,   backyard gardeners, health advocates and food  providers to  harvest and   donate excess produce into our local food system.  Our mission  is to connect people with food that would otherwise go to waste, reduce hunger  throughout the city, and build a sense of community. The leadership team  volunteers many hours of their own time to make harvests happen.<br />
    </p>
    <p>As a non-profit organization we are  entirely dependent on donations to support our efforts. If you share our  mission and would like to help, click the “Donate” button on our <a href="https://www.slofoodbank.org/make_a_donation.php" target="_blank">Support  page</a>.  <br />
    </p>
    <p><strong>What should I do if my contact information  changes?</strong> <br />
    </p>
    <p>If you are changing contact information like your email address or phone number, go to the <a href="../volunteer.php" target="_blank">Volunteer</a> page and click on 'Update.If you need to make a name change, write to Dick Yates at <a href="mailto:gleanslo@gleanweb.org">gleanslo@gleanweb.org</a>.<br />
    </p>
    <p><strong>Why won’t the signup page let me on the  roster?</strong> <br />
    </p>
    <p>You may have typed your name differently  than you did when you initially registered. You also need to check off the  Release and Waiver of Liability. If you are still unable to access the roster,  contact Dick at <a href="mailto:gleanslo@gleanweb.org">gleanslo@gleanweb.org</a> or (503) 991-5525.<br />
    </p>
    <p><strong>I forgot to write down the harvest  address!</strong> <br />
    </p>
    <p>The email you receive after you sign up  includes a link to information about the harvest, including the address. If you  have signed up for the harvest but have lost this email, go to the <a href="../index.php"  target="_blank">GleanSLO</a> website and click on the “Volunteer” button. Click the button there to  get another email. If you have any trouble, contact Dick.<br />
    </p>
    <p><strong>How are harvests planned?</strong></p>
    <p>Harvest leaders meet with crop owners to  scout the property and discuss harvest logistics. The size of the roster is  determined by the amount of produce, the number of available volunteer staff,  and parking space. Our goal is to accommodate as any people as possible.</p>
    <p>      We are indebted to property owners and  commercial growers who share our mission. Commercial growers are able to donate  for a variety of reasons. Sometimes produce is left over because it wasn’t sold  or wasn’t ripe at the time of harvest. Some crops are unsuitable for machine  harvests, and other crops are too small to fulfill a cannery contract. These  factors mean that we don’t know which large-scale crops will be available each  season, and often have only a few days’ notice to plan harvests.<br />
    </p>
    <p><strong>Can I bring my kids?</strong><br />
      <br />
    We encourage parents to bring their children, but please be aware that some  harvests will be more suitable for kids than others. No one under the  age of 13 may climb a ladder, and climbing trees is never allowed. If the  lowest fruit is not accessible from the ground, there are few opportunities for  younger children to help. We always provide as much information as possible  about the height of the tree and the lowest fruit, so that you can make the  decision about whether or not to bring your kids. Youth under age 18 don’t need  to register as volunteers, but parents are required to check off the waiver form,  agreeing to provide supervision. </p>
    <p>Volunteers under age 18 must be actively  supervised by an adult who is on the harvest roster. </p>
    <p>We believe that picking with GleanSLO is a valuable educational experience and a fabulous opportunity for  young folks to give back to the community. When we announce new harvests, we will call special attention to those that are appropriate for  children.<br />
      <br />
      <strong>What should I bring to the harvest?</strong></p>
    <ul>
        <li>Bring water to drink and take care of any  bathroom needs before arriving as we may or may not have access to restrooms  during the harvest. This will be noted in the harvest description after you  sign up.</li>
        <li>If you have an orchard ladder, please let us know and you may be encouraged to bring it. We always provide as much information as possible about the  height of the trees and the fruit, so that you can make the decision about  whether or not to bring a ladder. We will usually provide orchard ladders when  they are useful, and we ask volunteers to share in shifts. If you have an orchard  ladder, you are encouraged to bring it. Step ladders are not as stable as  orchard ladders, but they can be useful where the ground is level. Extension ladders  are not useful. No one under age 16 is allowed to climb a ladder. </li>
        <li>You may want to bring gloves for  handling wooden ladders and vinyl or nitrile (non-latex) gloves for picking fruit.</li>
        <li>Bring a reusable bag. Our volunteer gleaners pick for The Food Bank first, but when there is still excess food, and the farmer agrees, the volunteers can sample the harvest and take something home.</li>
    </ul>
      <p><strong>What should I wear?</strong><br />
      </p>
    <p>We suggest sunblock, a long-sleeved  T-shirt, long pants, comfortable closed-toe shoes and a hat (trees are often  dusty).<br />
    </p>
    <p><strong>Has the produce been sprayed with  chemicals?</strong> <br />
    </p>
    <p>Our harvests take place at a wide  variety of properties, from 10-acre orchards to urban backyards. We always ask  the property owner whether or not their fruit has been sprayed with non-organic  chemicals in the last three years, and we include that information when we  schedule the harvest.<br />
    </p>
    <p><strong>Do I have to stay for the entire time?</strong> <br />
    </p>
    <p>Since space is limited at many of the harvest sites, we ask that you register to harvest only when you can arrive on time and stay for the whole time until the crop is picked. Most harvests are scheduled for about two hours. <br />
    </p>
    <p><strong>Why do harvests fill so quickly?</strong> <br />
    </p>
<p>Many people have registered  with GleanSLO. When a harvest is posted, we believe it is most fair to  notify all volunteers at the same time. Unfortunately, at this time there is no  practical way to rotate signup opportunities. Those who take on greater leadership roles have a better chance of hearing about smaller, last-minute harvest.</p>
    <p><strong>Why aren’t there more harvests?</strong> <br />
    </p>
    <p>GleanSLO relies on donations from  crop owners. While we do want crop owners to be aware of our service, we do not  contact specific farmers to ask them to participate. After a crop is donated,  our leadership team considers how many harvests will be needed to harvest the  produce. We also consider our ability to staff the harvest, provide parking  space and accommodate requests from the crop owner. <br />
    </p>
    <p><strong>Who should I contact if I have other  questions?</strong> <br />
    </p>
    <p>Please check out the <a href="../contact.php"  target="_blank">Contacts</a> page.  We are always happy to help.</p>
    <p>&nbsp;</p>
<!-- end #mainContent --></div>
<br class="clearfloat" />
<!--<div id="footer">
<div style="float:right; width:170;"><a href="http://www.gleanweb.org" target="_blank"><img src="images/Nav buttons/gleanweb.png" alt="Website by GleanWeb" height="20" /></a></div>
<div style="width:700; "><center>Copyright © 2020 GleanSLO</center></div>
</div>-->
<div id="footer">
<div style="float:right; width:25%;text-align:right;"><a href="http://www.gleanweb.org" target="_blank"><img src="images/Nav buttons/gleanweb.png" alt="Website by GleanWeb" style="max-height:20px;" /></a></div>
<div style="float:right;width:35%;text-align:center;" id="google_translate_element"></div>
<script type="text/javascript">
function googleTranslateElementInit() { new google.translate.TranslateElement({pageLanguage: 'en', includedLanguages: 'es,en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element'); }
</script>
<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
<div style="width:39%; "><center>Copyright © 2020 GleanSLO</center></div>
</div>
<!-- end #container --></div>
</body>
</html>