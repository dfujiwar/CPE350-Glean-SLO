<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>register volunteer</title>
<link href="gleanslo.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
-->
</style>
</head>
<body class="SH">
<div id="container">
  <div id="header">
   <img src="images/banners/logobanner1.png" width="876" height="180" border="2" /> 
  </div>
<div class="navdiv">
    <div class="navigation">
        <div class="spacer">&nbsp;</div>
        <ul>
            <li><a href="index.php"><strong>Home</strong></a></li>
        <li><a><label class="lab" for="tog1">About</label></a>
				<input type="checkbox" id="tog1"/>
                <ul class="dropped" id="menu1">
                <li><a href="mission.php">Mission&nbsp;&&nbsp;vision</a></li>
                <li><a href="team.php">Our&nbsp;team</a></li>
                <li><a href="history.php">History</a></li>
                <li><a href="how.php">How&nbsp;it&nbsp;works</a></li>
                <li><a href="annual.php">What&nbsp;we've&nbsp;done</a></li>
                <li><a href="FAQ.php">FAQ</a></li>
                <li><a href="contact.php">Contact&nbsp;us</a></li>
                <li><a href="employment.php">Employment</a></li>
                </ul>
            </li>
            <li><a href="volunteer.php"><strong>Volunteer</strong></a></li>
            <li><a href="site_registration.php"><strong>Donate&nbsp;crop</strong></a></li>
        <li><a><label class="lab" for="tog2">Support</label></a>
				<input type="checkbox" id="tog2"/>
                <ul class="dropped" id="menu2">
                <li><a href="https://domains.giveffect.com/campaigns/10230-gleanslo" target="_blank">Donate</a></li>
                <li><a href="wish.php">Wish&nbsp;list</a></li>
                <li><a href="supporters.php">Supporters</a></li>
                <li><a href="sponsorship.php">Sponsorship</a></li>
                <li><a href="vehicle.php">Donate a vehicle</a></li>
                </ul>
             </li>
            <li><a href="harvestlist.php"><strong>Harvests</strong></a></li>
        </ul>
        </div>
        </div>
<div class="clearfloat"></div>
<div id="mainContent">
    <p></p>
    <div class="indentdiv">
      <form action="/pickerinsert.php?" id="pickerinsertform" name="pickerinsertform" method="POST">
        <h3>Volunteer Registration Form</h3>
        <p>Please fill out this form completely, then click Save.  Please note that this page will not sign you up to participate in a specific  harvest; remember to visit the Harvests  page to sign up for a particular  harvest. </p>
        <p><strong><em>If you have already registered before, you do not have to register again</em></strong>. If you want to <strong><em>update</em></strong> your contact information, go to the <a href="volunteer.php">Volunteer</a> page and click on 'Update.' If you have a name change, send an email to Dick at <a href="mailto:gleanslo@gleanweb.org">gleanslo@gleanweb.org</a>.</p>
        <p>Privacy: Information entered here is used solely by  GleanSLO. We do not share, sell or otherwise distribute  your personal information. </p>
        <p><strong>If you are under the age of 18 (or are registering for  your child), you MUST bring a copy of our <a href="documents/Release-Waiver-2016-05.pdf" target="_blank">Volunteer Waiver and Liability  Agreement</a> signed by a parent or legal guardian to your first glean.</strong></p>
<p><label>First name <input name="fname" type="text" id="fname" size="15" maxlength="15" /></label>
          <label>&nbsp;&nbsp;&nbsp;&nbsp;Last name <input name="lname" type="text" id="lname" size="20" maxlength="30" /></label></p>
        <p>
           Phone 
             <input name="phone" type="text" id="phone" size="15" maxlength="15" value="(000) 000-0000" style="color:#666;" onFocus="if(this.value == '(000) 000-0000') {this.value = '';}" onBlur="if (this.value == '') {this.value = '(000) 000-0000';}"/>
           Alternate Phone
           <input name="phone2" type="text" id="phone2" size="15" maxlength="15"  value="(000) 000-0000"  style="color:#666; " onFocus="if(this.value == '(000) 000-0000') {this.value = '';}" onBlur="if (this.value == '') {this.value = '(000) 000-0000';}"/></p>
        <p><label>Email <input name="email" type="text" id="email" size="30" maxlength="40" /></label></p>
        <p><label>Address <input name="address" type="text" id="address" size="30" maxlength="30" /></label></p>
        <p><label>City <input name="city" type="text" id="city" size="15" maxlength="20" /></label>
          <label>State <input name="state" type="text" id="state" size="4" maxlength="2" value="CA" /></label>
          <label>Zip code <input name="zip" type="text" id="zip" size="5" maxlength="5" /></label></p>
        <p>How do you want to help? (Check as many as you want)</p>
        <p class="tabin">
          <label>Picker <input type="radio" name="harvester" value="Yes" id="harvester_0" checked="checked" /> Yes</label>
          <label><input name="harvester" type="radio" id="harvester_1" value=""  /> No</label></p>
        <p class="tabin">
          <label>Harvest Assistant <input type="radio" name="intake" value="Yes" id="intake_0" /> Yes</label>
          <label><input name="intake" type="radio" id="intake_1" value="" checked="checked" /> No</label><br /></p>
        <p class="tabin">
          <label>Transport produce with my pickup truck <input type="radio" name="truck" value="Yes" id="truck_0" /> Yes</label>
          <label><input name="truck" type="radio" id="truck_1" value="" checked="checked" /> No</label><br /></p>
		<p> 
      <label>How did you hear about GleanSLO?
          <select name="how_hear" id="how_hear">
            <option value=" " selected="selected">[select]</option>
            <option value="Neighbor">Neighbor</option>
            <option value="GleanSLO web site">GleanSLO Web Site</option>
            <option value="SLO Food Bank">SLO Food Bank</option>
            <option value="GleanSLO volunteer">GleanSLO volunteer</option>
            <option value="Communication Students ">Cal Poly Communication Students</option>
            <option value="Newspaper">Newspaper</option>
            <option value="Facebook">Facebook</option>
            <option value="Flyer">Flyer</option>
            <option value="Craigslist">Craigslist</option>
            <option value="Other urban harvesting group">Other urban harvesting group</option>
            <option value="Friend">Friend</option>
            <option value="Other">Other</option>
            <option value="Web search">Web search</option>
          </select>
      </label>  
</p>
<p>You may enter an optional password (up to 15 letters and numbers only) that you can use to check your signups, history and waiting list status anytime instantly on a web page rather than waiting for an email. <br /><br />
		  <label>Password (optional): <input name="volpass" type="password" id="code" size="15" maxlength="15" /></label>
</p>
<p>Emergency contact (first and last name)
  <input name="emerg" type="text" size="40" maxlength="40" /></label></p>
<p>Emergency contact phone number <input name="ephone" type="text" size="20" maxlength="20"  value="(000) 000-0000"  style="color:#666; " onFocus="if(this.value == '(000) 000-0000') {this.value = '';}" onBlur="if (this.value == '') {this.value = '(000) 000-0000';}"/></p>
<p><input type="checkbox" name="waiver1" id="waiver1" />
   I agree to the <a href="Pickers/ParticipationTerms.php" target="_blank">Terms of Participation</a>.</p>

<p><label><input class="button" style="font-weight:bold;" type="submit" name="submit" id="submit" value="Save" /></label>
        After registering as a volunteer, please visit our <a href="harvestlist.php">harvests</a> page to  see what harvests are scheduled and to sign up for one.</p>
        <input type="hidden" name="MM_insert" value="pickerinsertform" />
      </form>
<p>&nbsp;</p>
</div>
 <!-- end #mainContent --></div>
<!-- This clearing element should immediately follow the #mainContent div in order to force the #container div to contain all child floats --><br class="clearfloat" />
<!--<div id="footer">
<div style="float:right; width:170;"><a href="http://www.gleanweb.org" target="_blank"><img src="images/Nav buttons/gleanweb.png" alt="Website by GleanWeb" height="20" /></a></div>
<div style="width:700; "><center>Copyright © 2020 GleanSLO</center></div>
</div>-->
<div id="footer">
<div style="float:right; width:25%;text-align:right;"><a href="http://www.gleanweb.org" target="_blank"><img src="images/Nav buttons/gleanweb.png" alt="Website by GleanWeb" style="max-height:20px;" /></a></div>
<div style="float:right;width:35%;text-align:center;" id="google_translate_element"></div>
<script type="text/javascript">
function googleTranslateElementInit() { new google.translate.TranslateElement({pageLanguage: 'en', includedLanguages: 'es,en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element'); }
</script>
<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
<div style="width:39%; "><center>Copyright © 2020 GleanSLO</center></div>
</div>
<!-- end #container --></div>
</body>
</html>
