<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Harvests</title>
<link href="gleanslo.css" rel="stylesheet" type="text/css" />
<style type="text/css">
.pop td, th {border:1px solid black; text-align:center;}
.harvhist td {text-align: center;}
</style>
<script>
function newDoc() {if(screen.width>800) window.location.assign("harvestlist.php");}
</script>
</head>
<body class="SH"  style="font-size:100% !important;" onload="newDoc()">
<div id="container">
  <div id="header">
   <img src="images/banners/logobanner1.png" width="876" height="180" border="2" /> 
  </div>
   <div class="navdiv">
    <div class="navigation">
        <div class="spacer">&nbsp;</div>
        <ul>
            <li><a href="index.php"><strong>Home</strong></a></li>
        <li><a><label class="lab" for="tog1">About</label></a>
				<input type="checkbox" id="tog1"/>
                <ul class="dropped" id="menu1">
                <li><a href="mission.php">Mission&nbsp;&&nbsp;vision</a></li>
                <li><a href="team.php">Our&nbsp;team</a></li>
                <li><a href="history.php">History</a></li>
                <li><a href="how.php">How&nbsp;it&nbsp;works</a></li>
                <li><a href="annual.php">What&nbsp;we've&nbsp;done</a></li>
                <li><a href="FAQ.php">FAQ</a></li>
                <li><a href="contact.php">Contact&nbsp;us</a></li>
                <li><a href="employment.php">Employment</a></li>
                </ul>
            </li>
            <li><a href="volunteer.php"><strong>Volunteer</strong></a></li>
            <li><a href="site_registration.php"><strong>Donate&nbsp;crop</strong></a></li>
        <li><a><label class="lab" for="tog2">Support</label></a>
				<input type="checkbox" id="tog2"/>
                <ul class="dropped" id="menu2">
                <li><a href="https://domains.giveffect.com/campaigns/10230-gleanslo" target="_blank">Donate</a></li>
                <li><a href="wish.php">Wish&nbsp;list</a></li>
                <li><a href="supporters.php">Supporters</a></li>
                <li><a href="sponsorship.php">Sponsorship</a></li>
                <li><a href="vehicle.php">Donate a vehicle</a></li>
                </ul>
             </li>
            <li><a href="harvestlist.php"><strong>Harvests</strong></a></li>
        </ul>
        </div>
        </div>
<div class="clearfloat"></div>
<div id="mainContent">
<h3><strong>Harvests and Other Events</strong></h3>
<p>Before signing up for an event, please be sure that you and each person signing up has registered previously on the <a href="pickerinsert.php" title="Harvester registration">Volunteers</a> page. If you have already registered as a volunteer you do not have to do so again. Each adult must sign up separately  for events. To sign up for an event, click on the 'Sign up for this event'  button. Once you sign up, you will receive a confirmation email with the exact  address and detailed information about the event. If the roster is full, your name will be  added to a waiting list and you will receive an email if anyone ahead of you  cancels their spot.</p>
<div style="width:100%;"> 
<div class="pop">
<table width="100%" cellpadding="3" cellspacing="0" id="harvestlist" style="border:3px solid #1C3F95;">
      			<tr>
            <th style="background-color:#23ba56; padding:5px; width:25%;"><form id="signup" name="signup" method="post" action="signup.php?access=public">
                <input name="harvesttemp" type="hidden" value="5284"/>
                <input type="submit" name="Submit2" id="Submit2" style="font-size:100%;width:100%; color:#ffffff; background-color:#23ba56; white-space:normal; border:0px;" onmouseover="style.fontWeight='bold'" onmouseout="style.fontWeight='normal'" value="Sign up for this event" />
             </form></th>
            <th colspan="3" style="background-color:#b136bf;"><span style="font-size: 2.5em; font-style: italic; text-shadow: 3px 3px 4px #000000;">
				FARMERS MARKET</span><br />
				Thursday, Jan 9, 7:30 PM</th>
</tr>
				<tr>
				<th style="background-color: #ffffff;"></th>
            <td>General location: San Luis Obispo</td>
				<td> </td>
          </tr>
          <tr>
            <th style="font-weight: normal;">Total volunteers needed</th>
            <th style="font-weight: normal;">Number on roster</th>
            <th style="font-weight: normal;">Number on waiting list</th>
            <th style="font-weight: normal;">
				</th>
          </tr>
          <tr>
            <td>2</td>
            <td>1</td>
            <td>0</td>
				<td>&nbsp;</td>
          </tr>
          <tr>
            <td colspan = "4" class="leftjustify">This is a market collection in downtown SLO at the Thursday night Farmers Market! 
Please do not sign up for this glean unless you have been trained specifically for the SLO Farmer's Market.  </td>
          </tr>
			<tr>
            <td colspan = "4" class="leftjustify">
            Getting there:
				 You will see the harvest address after signing up.            </td>
            </tr>
      </table>
		</div>
		<br />
  <div class="pop">
<table width="100%" cellpadding="3" cellspacing="0" id="harvestlist" style="border:3px solid #1C3F95;">
      			<tr>
            <th style="background-color:#23ba56; padding:5px; width:25%;"><form id="signup" name="signup" method="post" action="signup.php?access=public">
                <input name="harvesttemp" type="hidden" value="5280"/>
                <input type="submit" name="Submit2" id="Submit2" style="font-size:100%;width:100%; color:#ffffff; background-color:#23ba56; white-space:normal; border:0px;" onmouseover="style.fontWeight='bold'" onmouseout="style.fontWeight='normal'" value="Sign up for this event" />
             </form></th>
            <th colspan="3" style="background-color:#b136bf;"><span style="font-size: 2.5em; font-style: italic; text-shadow: 3px 3px 4px #000000;">
				kiwifruits</span><br />
				Friday, Jan 10, 9:00 AM</th>
</tr>
				<tr>
				<th style="background-color: #ffffff;"></th>
            <td>General location: Nipomo</td>
				<td> </td>
          </tr>
          <tr>
            <th style="font-weight: normal;">Total volunteers needed</th>
            <th style="font-weight: normal;">Number on roster</th>
            <th style="font-weight: normal;">Number on waiting list</th>
            <th style="font-weight: normal;">
				</th>
          </tr>
          <tr>
            <td>20</td>
            <td>11</td>
            <td>0</td>
				<td>&nbsp;</td>
          </tr>
          <tr>
            <td colspan = "4" class="leftjustify">This is a harvest of kiwis from a private farm in Nipomo- Adults and teens only, please! </td>
          </tr>
			<tr>
            <td colspan = "4" class="leftjustify">
            Getting there:
				 You will see the harvest address after signing up.            </td>
            </tr>
      </table>
		</div>
		<br />
  <div class="pop">
<table width="100%" cellpadding="3" cellspacing="0" id="harvestlist" style="border:3px solid #1C3F95;">
      			<tr>
            <th style="background-color:#d9252b; padding:5px; width:25%;"><form id="signup" name="signup" method="post" action="signup.php?access=public">
                <input name="harvesttemp" type="hidden" value="5301"/>
                <input type="submit" name="Submit2" id="Submit2" style="font-size:100%;width:100%; color:#ffffff; background-color:#d9252b; white-space:normal; border:0px;" onmouseover="style.fontWeight='bold'" onmouseout="style.fontWeight='normal'" value="Add name to waiting list" />
             </form></th>
            <th colspan="3" style="background-color:#b136bf;"><span style="font-size: 2.5em; font-style: italic; text-shadow: 3px 3px 4px #000000;">
				tangerines</span><br />
				Saturday, Jan 11, 9:00 AM</th>
</tr>
				<tr>
				<th style="background-color: #ffffff;"></th>
            <td>General location: Arroyo Grande</td>
				<td> </td>
          </tr>
          <tr>
            <th style="font-weight: normal;">Total volunteers needed</th>
            <th style="font-weight: normal;">Number on roster</th>
            <th style="font-weight: normal;">Number on waiting list</th>
            <th style="font-weight: normal;">
				</th>
          </tr>
          <tr>
            <td>4</td>
            <td>4</td>
            <td>1</td>
				<td>&nbsp;</td>
          </tr>
          <tr>
            <td colspan = "4" class="leftjustify">This is a neighborhood harvest of tangerines at a home in Arroyo Grande. Ladders and pole pickers may be necessary to reach all of the fruit. Ladder-friendly Adults and teens only.  </td>
          </tr>
			<tr>
            <td colspan = "4" class="leftjustify">
            Getting there:
				 You will see the harvest address after signing up.            </td>
            </tr>
      </table>
		</div>
		<br />
  <div class="pop">
<table width="100%" cellpadding="3" cellspacing="0" id="harvestlist" style="border:3px solid #1C3F95;">
      			<tr>
            <th style="background-color:#23ba56; padding:5px; width:25%;"><form id="signup" name="signup" method="post" action="signup.php?access=public">
                <input name="harvesttemp" type="hidden" value="5306"/>
                <input type="submit" name="Submit2" id="Submit2" style="font-size:100%;width:100%; color:#ffffff; background-color:#23ba56; white-space:normal; border:0px;" onmouseover="style.fontWeight='bold'" onmouseout="style.fontWeight='normal'" value="Sign up for this event" />
             </form></th>
            <th colspan="3" style="background-color:#b136bf;"><span style="font-size: 2.5em; font-style: italic; text-shadow: 3px 3px 4px #000000;">
				kiwifruits</span><br />
				Monday, Jan 13, 9:00 AM</th>
</tr>
				<tr>
				<th style="background-color: #ffffff;"></th>
            <td>General location: Nipomo</td>
				<td> </td>
          </tr>
          <tr>
            <th style="font-weight: normal;">Total volunteers needed</th>
            <th style="font-weight: normal;">Number on roster</th>
            <th style="font-weight: normal;">Number on waiting list</th>
            <th style="font-weight: normal;">
				</th>
          </tr>
          <tr>
            <td>20</td>
            <td>1</td>
            <td>0</td>
				<td>&nbsp;</td>
          </tr>
          <tr>
            <td colspan = "4" class="leftjustify">This is a harvest of kiwis from a private farm in Nipomo- Adults and teens only, please! </td>
          </tr>
			<tr>
            <td colspan = "4" class="leftjustify">
            Getting there:
				 You will see the harvest address after signing up.            </td>
            </tr>
      </table>
		</div>
		<br />
  <div class="pop">
<table width="100%" cellpadding="3" cellspacing="0" id="harvestlist" style="border:3px solid #1C3F95;">
      			<tr>
            <th style="background-color:#23ba56; padding:5px; width:25%;"><form id="signup" name="signup" method="post" action="signup.php?access=public">
                <input name="harvesttemp" type="hidden" value="5308"/>
                <input type="submit" name="Submit2" id="Submit2" style="font-size:100%;width:100%; color:#ffffff; background-color:#23ba56; white-space:normal; border:0px;" onmouseover="style.fontWeight='bold'" onmouseout="style.fontWeight='normal'" value="Sign up for this event" />
             </form></th>
            <th colspan="3" style="background-color:#b136bf;"><span style="font-size: 2.5em; font-style: italic; text-shadow: 3px 3px 4px #000000;">
				apples</span><br />
				Tuesday, Jan 14, 9:00 AM</th>
</tr>
				<tr>
				<th style="background-color: #ffffff;"></th>
            <td>General location: SLO, See Canyon</td>
				<td> </td>
          </tr>
          <tr>
            <th style="font-weight: normal;">Total volunteers needed</th>
            <th style="font-weight: normal;">Number on roster</th>
            <th style="font-weight: normal;">Number on waiting list</th>
            <th style="font-weight: normal;">
				</th>
          </tr>
          <tr>
            <td>20</td>
            <td>1</td>
            <td>0</td>
				<td>&nbsp;</td>
          </tr>
          <tr>
            <td colspan = "4" class="leftjustify">This is an apple glean at an orchard in See Canyon- read special instructions about where to meet after signing up. Adults and teens only, please! </td>
          </tr>
			<tr>
            <td colspan = "4" class="leftjustify">
            Getting there:
				 You will see the harvest address after signing up.            </td>
            </tr>
      </table>
		</div>
		<br />
  <div class="pop">
<table width="100%" cellpadding="3" cellspacing="0" id="harvestlist" style="border:3px solid #1C3F95;">
      			<tr>
            <th style="background-color:#23ba56; padding:5px; width:25%;"><form id="signup" name="signup" method="post" action="signup.php?access=public">
                <input name="harvesttemp" type="hidden" value="5285"/>
                <input type="submit" name="Submit2" id="Submit2" style="font-size:100%;width:100%; color:#ffffff; background-color:#23ba56; white-space:normal; border:0px;" onmouseover="style.fontWeight='bold'" onmouseout="style.fontWeight='normal'" value="Sign up for this event" />
             </form></th>
            <th colspan="3" style="background-color:#b136bf;"><span style="font-size: 2.5em; font-style: italic; text-shadow: 3px 3px 4px #000000;">
				FARMERS MARKET</span><br />
				Thursday, Jan 16, 7:30 PM</th>
</tr>
				<tr>
				<th style="background-color: #ffffff;"></th>
            <td>General location: San Luis Obispo</td>
				<td> </td>
          </tr>
          <tr>
            <th style="font-weight: normal;">Total volunteers needed</th>
            <th style="font-weight: normal;">Number on roster</th>
            <th style="font-weight: normal;">Number on waiting list</th>
            <th style="font-weight: normal;">
				</th>
          </tr>
          <tr>
            <td>2</td>
            <td>0</td>
            <td>0</td>
				<td>&nbsp;</td>
          </tr>
          <tr>
            <td colspan = "4" class="leftjustify">This is a market collection in downtown SLO at the Thursday night Farmers Market! 
Please do not sign up for this glean unless you have been trained specifically for the SLO Farmer's Market.  </td>
          </tr>
			<tr>
            <td colspan = "4" class="leftjustify">
            Getting there:
				 You will see the harvest address after signing up.            </td>
            </tr>
      </table>
		</div>
		<br />
  <div class="pop">
<table width="100%" cellpadding="3" cellspacing="0" id="harvestlist" style="border:3px solid #1C3F95;">
      			<tr>
            <th style="background-color:#23ba56; padding:5px; width:25%;"><form id="signup" name="signup" method="post" action="signup.php?access=public">
                <input name="harvesttemp" type="hidden" value="5307"/>
                <input type="submit" name="Submit2" id="Submit2" style="font-size:100%;width:100%; color:#ffffff; background-color:#23ba56; white-space:normal; border:0px;" onmouseover="style.fontWeight='bold'" onmouseout="style.fontWeight='normal'" value="Sign up for this event" />
             </form></th>
            <th colspan="3" style="background-color:#b136bf;"><span style="font-size: 2.5em; font-style: italic; text-shadow: 3px 3px 4px #000000;">
				kiwifruits</span><br />
				Friday, Jan 17, 9:00 AM</th>
</tr>
				<tr>
				<th style="background-color: #ffffff;"></th>
            <td>General location: Nipomo</td>
				<td> </td>
          </tr>
          <tr>
            <th style="font-weight: normal;">Total volunteers needed</th>
            <th style="font-weight: normal;">Number on roster</th>
            <th style="font-weight: normal;">Number on waiting list</th>
            <th style="font-weight: normal;">
				</th>
          </tr>
          <tr>
            <td>20</td>
            <td>1</td>
            <td>0</td>
				<td>&nbsp;</td>
          </tr>
          <tr>
            <td colspan = "4" class="leftjustify">This is a harvest of kiwis from a private farm in Nipomo- Adults and teens only, please! </td>
          </tr>
			<tr>
            <td colspan = "4" class="leftjustify">
            Getting there:
				 You will see the harvest address after signing up.            </td>
            </tr>
      </table>
		</div>
		<br />
  <div class="pop">
<table width="100%" cellpadding="3" cellspacing="0" id="harvestlist" style="border:3px solid #1C3F95;">
      			<tr>
            <th style="background-color:#23ba56; padding:5px; width:25%;"><form id="signup" name="signup" method="post" action="signup.php?access=public">
                <input name="harvesttemp" type="hidden" value="5286"/>
                <input type="submit" name="Submit2" id="Submit2" style="font-size:100%;width:100%; color:#ffffff; background-color:#23ba56; white-space:normal; border:0px;" onmouseover="style.fontWeight='bold'" onmouseout="style.fontWeight='normal'" value="Sign up for this event" />
             </form></th>
            <th colspan="3" style="background-color:#b136bf;"><span style="font-size: 2.5em; font-style: italic; text-shadow: 3px 3px 4px #000000;">
				FARMERS MARKET</span><br />
				Thursday, Jan 23, 7:30 PM</th>
</tr>
				<tr>
				<th style="background-color: #ffffff;"></th>
            <td>General location: San Luis Obispo</td>
				<td> </td>
          </tr>
          <tr>
            <th style="font-weight: normal;">Total volunteers needed</th>
            <th style="font-weight: normal;">Number on roster</th>
            <th style="font-weight: normal;">Number on waiting list</th>
            <th style="font-weight: normal;">
				</th>
          </tr>
          <tr>
            <td>2</td>
            <td>0</td>
            <td>0</td>
				<td>&nbsp;</td>
          </tr>
          <tr>
            <td colspan = "4" class="leftjustify">This is a market collection in downtown SLO at the Thursday night Farmers Market! 
Please do not sign up for this glean unless you have been trained specifically for the SLO Farmer's Market.  </td>
          </tr>
			<tr>
            <td colspan = "4" class="leftjustify">
            Getting there:
				 You will see the harvest address after signing up.            </td>
            </tr>
      </table>
		</div>
		<br />
  <div class="pop">
<table width="100%" cellpadding="3" cellspacing="0" id="harvestlist" style="border:3px solid #1C3F95;">
      			<tr>
            <th style="background-color:#23ba56; padding:5px; width:25%;"><form id="signup" name="signup" method="post" action="signup.php?access=public">
                <input name="harvesttemp" type="hidden" value="5287"/>
                <input type="submit" name="Submit2" id="Submit2" style="font-size:100%;width:100%; color:#ffffff; background-color:#23ba56; white-space:normal; border:0px;" onmouseover="style.fontWeight='bold'" onmouseout="style.fontWeight='normal'" value="Sign up for this event" />
             </form></th>
            <th colspan="3" style="background-color:#b136bf;"><span style="font-size: 2.5em; font-style: italic; text-shadow: 3px 3px 4px #000000;">
				FARMERS MARKET</span><br />
				Thursday, Jan 30, 7:30 PM</th>
</tr>
				<tr>
				<th style="background-color: #ffffff;"></th>
            <td>General location: San Luis Obispo</td>
				<td> </td>
          </tr>
          <tr>
            <th style="font-weight: normal;">Total volunteers needed</th>
            <th style="font-weight: normal;">Number on roster</th>
            <th style="font-weight: normal;">Number on waiting list</th>
            <th style="font-weight: normal;">
				</th>
          </tr>
          <tr>
            <td>2</td>
            <td>0</td>
            <td>0</td>
				<td>&nbsp;</td>
          </tr>
          <tr>
            <td colspan = "4" class="leftjustify">This is a market collection in downtown SLO at the Thursday night Farmers Market! 
Please do not sign up for this glean unless you have been trained specifically for the SLO Farmer's Market.  </td>
          </tr>
			<tr>
            <td colspan = "4" class="leftjustify">
            Getting there:
				 You will see the harvest address after signing up.            </td>
            </tr>
      </table>
		</div>
		<br />
  </div> 
  <p>&nbsp;</p>
  <table width="60%" border="0" cellpadding="1" cellspacing="1" id="facebook" align="center">
    <tr>
      <td>To get the latest news and updates about GleanSLO, visit our Facebook page.</td>
      <td><a href="https://www.facebook.com/pages/GleanSLO/290283964316368"><img src="images/Facebook.png" width="120"/></a></td>
    </tr>
  </table>
  <br />
  <table class="harvhist" width="50%" align="center" border="2" cellspacing="2" cellpadding="5">
	 <tr>
		  <th style="color:white;width:40%;">Year</th>
		  <th style="color:white;">Pounds of food that would otherwise have gone to waste</th>
        </tr>
 <tr><td>2020</td>
			<td>1,589</td>
	 </tr>
<tr><td>2019</td>
			<td>229,095</td>
	 </tr>
<tr><td>2018</td>
			<td>231,377</td>
	 </tr>
<tr><td>2017</td>
			<td>279,830</td>
	 </tr>
<tr><td>2016</td>
			<td>243,312</td>
	 </tr>
<tr><td>2015</td>
			<td>209,013</td>
	 </tr>
<tr><td>2014</td>
			<td>200,092</td>
	 </tr>
<tr><td>2013</td>
			<td>212,109</td>
	 </tr>
		<tr><td>2012</td>
        	<td>99,165</td>
	    </tr>
		<tr><td>2011</td>
        	<td>37,988</td>
	    </tr>        
		<tr><td>2010</td>
        	<td>22,000</td>
	    </tr>        
    </table>
  <p>&nbsp;</p>
 </div> 
<!--<div id="footer">
<div style="float:right; width:170;"><a href="http://www.gleanweb.org" target="_blank"><img src="images/Nav buttons/gleanweb.png" alt="Website by GleanWeb" height="20" /></a></div>
<div style="width:700; "><center>Copyright © 2020 GleanSLO</center></div>
</div>-->
<div id="footer">
<div style="float:right; width:25%;text-align:right;"><a href="http://www.gleanweb.org" target="_blank"><img src="images/Nav buttons/gleanweb.png" alt="Website by GleanWeb" style="max-height:20px;" /></a></div>
<div style="float:right;width:35%;text-align:center;" id="google_translate_element"></div>
<script type="text/javascript">
function googleTranslateElementInit() { new google.translate.TranslateElement({pageLanguage: 'en', includedLanguages: 'es,en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element'); }
</script>
<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
<div style="width:39%; "><center>Copyright © 2020 GleanSLO</center></div>
</div>
</div>
</body>
</html>
