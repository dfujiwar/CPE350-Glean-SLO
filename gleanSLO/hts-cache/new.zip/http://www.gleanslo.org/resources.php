<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Resources</title>
<link href="gleanslo.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
-->
</style>
</head>
<body class="SH">
<div id="container">
  <div id="header">
   <img src="images/banners/logobanner1.png" width="876" height="180" border="2" /> 
  </div>
<div class="navdiv">
    <div class="navigation">
        <div class="spacer">&nbsp;</div>
        <ul>
            <li><a href="index.php"><strong>Home</strong></a></li>
        <li><a><label class="lab" for="tog1">About</label></a>
				<input type="checkbox" id="tog1"/>
                <ul class="dropped" id="menu1">
                <li><a href="mission.php">Mission&nbsp;&&nbsp;vision</a></li>
                <li><a href="team.php">Our&nbsp;team</a></li>
                <li><a href="history.php">History</a></li>
                <li><a href="how.php">How&nbsp;it&nbsp;works</a></li>
                <li><a href="annual.php">What&nbsp;we've&nbsp;done</a></li>
                <li><a href="FAQ.php">FAQ</a></li>
                <li><a href="contact.php">Contact&nbsp;us</a></li>
                <li><a href="employment.php">Employment</a></li>
                </ul>
            </li>
            <li><a href="volunteer.php"><strong>Volunteer</strong></a></li>
            <li><a href="site_registration.php"><strong>Donate&nbsp;crop</strong></a></li>
        <li><a><label class="lab" for="tog2">Support</label></a>
				<input type="checkbox" id="tog2"/>
                <ul class="dropped" id="menu2">
                <li><a href="https://domains.giveffect.com/campaigns/10230-gleanslo" target="_blank">Donate</a></li>
                <li><a href="wish.php">Wish&nbsp;list</a></li>
                <li><a href="supporters.php">Supporters</a></li>
                <li><a href="sponsorship.php">Sponsorship</a></li>
                <li><a href="vehicle.php">Donate a vehicle</a></li>
                </ul>
             </li>
            <li><a href="harvestlist.php"><strong>Harvests</strong></a></li>
        </ul>
        </div>
        </div>
<div class="clearfloat"></div>
<div id="mainContent">
 <div id="narrowbody">
<p><img src="images/logos/logo-small.png" width="230"/></p>
<h3>Resources</h3>
<p><strong><a href="https://fallingfruit.org" target="_blank">Falling Fruit</a></strong></p>

<p><a href="https://fallingfruit.org" target="_blank">Falling Fruit</a> is a celebration of the overlooked culinary bounty of our city streets. By quantifying this resource on an interactive map, Falling Fruit hopes to facilitate intimate connections between people, food, and the natural organisms growing in our neighborhoods.</p> 

<p><strong>Survey Results</strong></p>

<p>In October 2014, GleanSLO polled the community for an Operations and Strategic Planning Survey. A summary of the results can be found <a href="documents/GleanSLO-Survey-Results.pdf">here</a>.</p>
<p style="font-size:16px;font-weight:bold;">Food Preservation</p>
<p>The Master Food Preservers (MFP) program is now taking calls about questions on food safety, canning fruits and vegetables, freezing, drying, pickling and jelly and jam making!</p>
		<p>
			<span style="font-family:arial,helvetica,sans-serif;">Call their hotline on Wednesdays between 1:00pm - 3:00pm, (805) 781-1429.    More info <a href="documents/60195.pdf">here</a>. </span></p>
<p></p>
<p><strong><span style="font-size:16px;"><span style="font-family:arial,helvetica,sans-serif;">Climate Friendly Food</span></span></strong></p><a href="documents/FINAL_ClimateFriendlyFood_08-26-2014.pdf" target="_blank" style="outline:0; padding-left:0px;"><img src="images/logos/OutsideIn_logofinal.jpg" alt="OutsideInSLO" width="200px"/></a>

<p>GleanSLO is a proud partner of OutsideInSLO because we believe what we choose to eat matters to our health and our climate.</p>
<p>OutsideInSLO is the first public health campaign linking climate change and health impacts in California. The goal of OutsideInSLO is to educate the community on the connections between climate change and health while empowering the community to make healthy choices which have multiple benefits.</p>

<p><em>“We at the <a href="https://www.facebook.com/slo.foodbank">SLO Food Bank</a> take climate change seriously by rescuing safe food that would go to the landfill and gleaning fresh produce locally through GleanSLO. It's part of our mission to help build a healthier community."</em> - Carl Hansen, CEO Food Bank Coalition of SLO County</p>

<p>Download the climate friendly food brochure <a href="http://www.healslo.com/wp-content/uploads/2014/09/FINAL_ClimateFriendlyFood_08-26-2014.pdf">here</a>.</p>


<p><strong><span style="font-size:16px;"><span style="font-family:arial,helvetica,sans-serif;">One Cool Earth</span></span></strong></p>

<p>One Cool Earth believes that every child deserves a place to grow. We create amazing school gardens that power healthy, happy, smart youth.<p>

For more information click 
<a href="http://www.onecoolearth.org">here</a>

 
 </div>
<p><br />
</p>
 <!-- end #mainContent --></div>
<!-- This clearing element should immediately follow the #mainContent div in order to force the #container div to contain all child floats --><br class="clearfloat" />
<!--<div id="footer">
<div style="float:right; width:170;"><a href="http://www.gleanweb.org" target="_blank"><img src="images/Nav buttons/gleanweb.png" alt="Website by GleanWeb" height="20" /></a></div>
<div style="width:700; "><center>Copyright © 2020 GleanSLO</center></div>
</div>-->
<div id="footer">
<div style="float:right; width:25%;text-align:right;"><a href="http://www.gleanweb.org" target="_blank"><img src="images/Nav buttons/gleanweb.png" alt="Website by GleanWeb" style="max-height:20px;" /></a></div>
<div style="float:right;width:35%;text-align:center;" id="google_translate_element"></div>
<script type="text/javascript">
function googleTranslateElementInit() { new google.translate.TranslateElement({pageLanguage: 'en', includedLanguages: 'es,en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element'); }
</script>
<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
<div style="width:39%; "><center>Copyright © 2020 GleanSLO</center></div>
</div>
<!-- end #container --></div>
</body>
</html>
