<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>How it Works</title>
<link href="gleanslo.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
-->
</style>
</head>
<body class="SH">
<div id="container">
<div id="header">
<img src="images/banners/logobanner1.png" width="876" height="180" border="2" /> 
</div>
<div class="navdiv">
    <div class="navigation">
        <div class="spacer">&nbsp;</div>
        <ul>
            <li><a href="index.php"><strong>Home</strong></a></li>
        <li><a><label class="lab" for="tog1">About</label></a>
				<input type="checkbox" id="tog1"/>
                <ul class="dropped" id="menu1">
                <li><a href="mission.php">Mission&nbsp;&&nbsp;vision</a></li>
                <li><a href="team.php">Our&nbsp;team</a></li>
                <li><a href="history.php">History</a></li>
                <li><a href="how.php">How&nbsp;it&nbsp;works</a></li>
                <li><a href="annual.php">What&nbsp;we've&nbsp;done</a></li>
                <li><a href="FAQ.php">FAQ</a></li>
                <li><a href="contact.php">Contact&nbsp;us</a></li>
                <li><a href="employment.php">Employment</a></li>
                </ul>
            </li>
            <li><a href="volunteer.php"><strong>Volunteer</strong></a></li>
            <li><a href="site_registration.php"><strong>Donate&nbsp;crop</strong></a></li>
        <li><a><label class="lab" for="tog2">Support</label></a>
				<input type="checkbox" id="tog2"/>
                <ul class="dropped" id="menu2">
                <li><a href="https://domains.giveffect.com/campaigns/10230-gleanslo" target="_blank">Donate</a></li>
                <li><a href="wish.php">Wish&nbsp;list</a></li>
                <li><a href="supporters.php">Supporters</a></li>
                <li><a href="sponsorship.php">Sponsorship</a></li>
                <li><a href="vehicle.php">Donate a vehicle</a></li>
                </ul>
             </li>
            <li><a href="harvestlist.php"><strong>Harvests</strong></a></li>
        </ul>
        </div>
        </div>
<div class="clearfloat"></div>
<div id="mainContent">
 <div id="narrowbody">
<p><img src="images/logos/logo-small.png" width="230"/></p>
<span style="font-family:arial,helvetica,sans-serif;"></span></p>
		<h3 style="font-size: 1.4em; font-family: Arial, Helvetica, sans-serif; background-color: rgb(255, 255, 255);">
			<span style="font-family:arial,helvetica,sans-serif;">What is gleaning?</span></h3>
<p>
			<span style="font-family:arial,helvetica,sans-serif;"><span style="background-color: rgb(255, 255, 255); font-size: 16px;">Gleaning is <b>the collection of leftover crops, both large and small, from farmers' fields after they have been commercially harvested or from fields where it is not economically profitable to harvest.</b> GleanSLO has expanded this definition to include <b>the collection of surplus produce from backyards and gardens of community residents.</b></span></span></p>
		<p>

<h3>Here's how GleanSLO works</h3>
<div style="float:right;width:38%;margin-left:15px;padding:15px;background-color:#448; color:#d2e2f7">
<p><strong><center>Testimonials</center></strong></p>
<p><center>From a farmer</center><br /><br />
<em>I had an excellent experience with GleanSLO. They were easy to work with, scheduling and harvesting went smoothly. Their staff and volunteers were very professional. It’s an all around great organization. I was happy to see my extra corn get to people in need.</em><br /><br /> -Steve Lechuga, corn grower</p><br />

<p><center>From a homeowner</center><br /><br />
<em>GleanSLO got our bountiful harvest to a place that could do so much good.  I was so grateful that someone would come do that.  Better for the trees, better for those of our county and better for the environment.  I feel great being a part of your commitment.</em><br /><br /> -Robinette Cantrell, homeowner</p><br />

<p><center>From a Neighborhood Harvest Leader</center><br /><br />
<em>I glean because I love to cook with fresh produce and eat lots of fresh fruit, and I am aware that not everybody can afford these. I don't like any kind of wasting and I am happy to contribute to honoring nature's abundance. I love the physical work and that it lasts only 2 or 3 hours, I love being connected to earth and plants and the other gleaners – there are so many interesting people among gleaners, and it's wonderful to meet them again at another glean.</em><br /><br /> -Deborah Berger, volunteer</p>
</div>

<img src="images/howitworks.jpg" width="52%" alt="How it works"/>
<ul type="disc">
<li><b>Contact</b><br />Many commercial growers and private homeowners have fruit trees, bushes, vines       or entire orchards and fields that produce more fresh fruit or vegetables than they can harvest. We invite them to <a href="site_registration.php">register</a> their crops online. Donations are tax deductible.</li><br />
   <li><b>Harvest</b><br />Working closely with growers, GleanSLO employees or volunteer leaders organize       harvests to gather the fresh produce. Volunteer pickers sign up online, checking off a liability waiver that protects crop owners.</li><br />
   <li><b>Distribute</b><br />The produce collected is distributed by the Food Bank Coalition to our neighbors in need. Over 46,000 San Luis Obispo County residents are served by the Food Bank yearly.</li>
</ul>
<p><i>What we choose to eat matters to our health and our climate.</i></p> </div>
 <!-- end #mainContent -->
  
 <br class="clearfloat" />
</div>
<!--<div id="footer">
<div style="float:right; width:170;"><a href="http://www.gleanweb.org" target="_blank"><img src="images/Nav buttons/gleanweb.png" alt="Website by GleanWeb" height="20" /></a></div>
<div style="width:700; "><center>Copyright © 2020 GleanSLO</center></div>
</div>-->
<div id="footer">
<div style="float:right; width:25%;text-align:right;"><a href="http://www.gleanweb.org" target="_blank"><img src="images/Nav buttons/gleanweb.png" alt="Website by GleanWeb" style="max-height:20px;" /></a></div>
<div style="float:right;width:35%;text-align:center;" id="google_translate_element"></div>
<script type="text/javascript">
function googleTranslateElementInit() { new google.translate.TranslateElement({pageLanguage: 'en', includedLanguages: 'es,en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element'); }
</script>
<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
<div style="width:39%; "><center>Copyright © 2020 GleanSLO</center></div>
</div>
<!-- end #container -->
 <br class="clearfloat" />
</div>
</body>
</html>
