<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Newsletter</title>
<link href="gleanslo.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
-->
</style>
</head>
<body class="SH">
<div id="container">
<div id="header">
<img src="images/banners/logobanner1.png" width="876" height="180" border="2" /> 
</div>
<div class="navdiv">
    <div class="navigation">
        <div class="spacer">&nbsp;</div>
        <ul>
            <li><a href="index.php"><strong>Home</strong></a></li>
        <li><a><label class="lab" for="tog1">About</label></a>
				<input type="checkbox" id="tog1"/>
                <ul class="dropped" id="menu1">
                <li><a href="mission.php">Mission&nbsp;&&nbsp;vision</a></li>
                <li><a href="team.php">Our&nbsp;team</a></li>
                <li><a href="history.php">History</a></li>
                <li><a href="how.php">How&nbsp;it&nbsp;works</a></li>
                <li><a href="annual.php">What&nbsp;we've&nbsp;done</a></li>
                <li><a href="FAQ.php">FAQ</a></li>
                <li><a href="contact.php">Contact&nbsp;us</a></li>
                <li><a href="employment.php">Employment</a></li>
                </ul>
            </li>
            <li><a href="volunteer.php"><strong>Volunteer</strong></a></li>
            <li><a href="site_registration.php"><strong>Donate&nbsp;crop</strong></a></li>
        <li><a><label class="lab" for="tog2">Support</label></a>
				<input type="checkbox" id="tog2"/>
                <ul class="dropped" id="menu2">
                <li><a href="https://domains.giveffect.com/campaigns/10230-gleanslo" target="_blank">Donate</a></li>
                <li><a href="wish.php">Wish&nbsp;list</a></li>
                <li><a href="supporters.php">Supporters</a></li>
                <li><a href="sponsorship.php">Sponsorship</a></li>
                <li><a href="vehicle.php">Donate a vehicle</a></li>
                </ul>
             </li>
            <li><a href="harvestlist.php"><strong>Harvests</strong></a></li>
        </ul>
        </div>
        </div>
<div class="clearfloat"></div>
<div id="mainContent">
 <div id="narrowbody">
<p><img src="images/logos/logo-small.png" width="230"/></p>
<div align="center">
<table border="0" cellspacing="0" cellpadding="3" bgcolor="#d2e2f7" style="border:2px solid #000000;">
<tr>
<td align="center" style="font-family:Arial; font-size:16px; color:#000000;"><strong>Newsletter</strong><br />Receive the latest news and updates</td>
</tr>
<tr>
<td align="center" style="border-top:2px solid #000000">
<form name="ccoptin" action="http://visitor.r20.constantcontact.com/d.jsp" target="_blank" method="post" style="margin-bottom:2;">
<input type="hidden" name="llr" value="4eiviyhab">
<input type="hidden" name="m" value="1107842211999">
<input type="hidden" name="p" value="oi">
<font style="font-weight: normal; font-family:Arial; font-size:16px; color:#000000;">Email:</font> <input type="text" name="ea" size="30" value="" style="font-size:10pt; border:1px solid #999999;">
<input type="submit" name="go" value="Sign up now" class="submit" style="font-family:Verdana,Geneva,Arial,Helvetica,sans-serif; font-size:10pt;">
</form>
</td>
</tr>
</table>
</div>
<h3>Newsletter Archives</h3>

<div style="column-count:4; column-rule: 2px solid darkblue; column-gap: 40px;">

<h2>2019</h2>
<blockquote>
<a href="https://mailchi.mp/slofoodbank/apples-tomoatoes-and-pears-oh-my-2100189?e=[UNIQID]">January</a>
<br />
<a href="https://mailchi.mp/slofoodbank/apples-tomoatoes-and-pears-oh-my-2100209?e=[UNIQID]">February</a>
<br />
<a href="https://mailchi.mp/slofoodbank/apples-tomoatoes-and-pears-oh-my-2100229?e=[UNIQID]">March</a>
<br />
<a href="https://mailchi.mp/slofoodbank/apples-tomoatoes-and-pears-oh-my-2100261?e=[UNIQID]">April</a>
<br />
<a href="https://mailchi.mp/slofoodbank/apples-tomoatoes-and-pears-oh-my-2100301?e=[UNIQID]">May</a>
<br />
<a href="https://mailchi.mp/slofoodbank/apples-tomoatoes-and-pears-oh-my-2100329?e=[UNIQID]">June</a>
<br />
<a href="https://mailchi.mp/slofoodbank/apples-tomoatoes-and-pears-oh-my-2100357?e=[UNIQID]">July</a>
<br />
<a href="https://mailchi.mp/slofoodbank/apples-tomoatoes-and-pears-oh-my-2100377?e=[UNIQID]">August</a>
<br />
<a href="https://mailchi.mp/slofoodbank/apples-tomoatoes-and-pears-oh-my-2100393?e=[UNIQID]">September</a>
<br />
</blockquote>
<br />
<br />
<br />

<h2>2018</h2>
<blockquote>
<a href="https://mailchi.mp/slofoodbank/apples-tomoatoes-and-pears-oh-my-2099825?e=011acb2065">January</a>
<br />
<a href="https://mailchi.mp/slofoodbank/apples-tomoatoes-and-pears-oh-my-2099841?e=[UNIQID]">February</a>
<br />
<a href="https://mailchi.mp/slofoodbank/apples-tomoatoes-and-pears-oh-my-2099869?e=[UNIQID]">March</a>
<br />
<a href="https://mailchi.mp/slofoodbank/apples-tomoatoes-and-pears-oh-my-2099901?e=[UNIQID]">April</a>
<br />
<a href="https://mailchi.mp/slofoodbank/apples-tomoatoes-and-pears-oh-my-2099937?e=[UNIQID]">May</a>
<br />
<a href="https://mailchi.mp/slofoodbank/apples-tomoatoes-and-pears-oh-my-2099981?e=[UNIQID]">June</a>
<br />
<a href="https://mailchi.mp/slofoodbank/apples-tomoatoes-and-pears-oh-my-2100017?e=[UNIQID]">July</a>
<br />
<a href="https://us9.campaign-archive.com/?e=&u=a18c518cc0e8c7e5625e6aa9b&id=f7c54880e0">August</a>
<br />
<a href="https://mailchi.mp/slofoodbank/apples-tomoatoes-and-pears-oh-my-2100089?e=011acb2065">September</a>
<br />
<a href="https://us9.campaign-archive.com/?e=[UNIQID]&u=a18c518cc0e8c7e5625e6aa9b&id=b56aca9fe3">October</a>
<br />
<a href="https://mailchi.mp/slofoodbank/apples-tomoatoes-and-pears-oh-my-2100153?e=[UNIQID]">November</a>
<br />
<a href="https://mailchi.mp/slofoodbank/apples-tomoatoes-and-pears-oh-my-2100177?e=[UNIQID]">December</a>
<br />
</blockquote>
<br />
<br />
<br />

<h2>2017</h2>
<blockquote>
<a href="http://us9.campaign-archive2.com/?u=a18c518cc0e8c7e5625e6aa9b&id=f7e54fbcb6" target="_blank">January</a>
<br />
<a href="http://eepurl.com/cD2fJb"_blank">February</a>
<br />
<a href="http://us9.campaign-archive2.com/?u=a18c518cc0e8c7e5625e6aa9b&id=273ff9a8e3&e=67872eeec6" target="_blank">March</a>
<br />
<a href="http://mailchi.mp/slofoodbank/gleans-and-events-coming-your-way" target="_blank">April</a>
<br />
<a href="http://mailchi.mp/slofoodbank/were-biking-planting-fundraising-and-more?e=d9e87269e3k">May</a>
<br />
<a href="http://mailchi.mp/slofoodbank/gleanslo_gleansgalor?e=d9e87269e3">June</a>
<br />
<a href="http://mailchi.mp/slofoodbank/gleanslo_parties_gleans_and_more?e=8355b2d49a">July</a>
<br />
<a href="http://mailchi.mp/slofoodbank/goodbyes-events-and-gleanslo-is-hiring?e=011acb2065">August</a>
<br />
<a href="http://mailchi.mp/slofoodbank/apples-tomoatoes-and-pears-oh-my?e=[UNIQID]">September</a>
<br />
<a href="http://mailchi.mp/slofoodbank/apples-tomoatoes-and-pears-oh-my-2099753?e=011acb2065">October</a>
<br />
<a href="http://mailchi.mp/slofoodbank/apples-tomoatoes-and-pears-oh-my-2099781?e=011acb2065">November</a>
<br />
<a href="http://mailchi.mp/slofoodbank/apples-tomoatoes-and-pears-oh-my-2099797?e=011acb2065">December</a>
<br />
</blockquote>

<h2>2016</h2>
<blockquote>
<a href="http://us9.campaign-archive1.com/?u=a18c518cc0e8c7e5625e6aa9b&id=3c18d6ec04&e=[UNIQID]" target="_blank">January</a>
<br />
<a href="http://us9.campaign-archive2.com/?u=a18c518cc0e8c7e5625e6aa9b&id=6892237335&e=[UNIQID]" target="_blank">February</a>
<br />
<a href="http://us9.campaign-archive2.com/?u=a18c518cc0e8c7e5625e6aa9b&id=66c2df1f36&e=[UNIQID]" target="_blank">March</a>
<br />
<a href="http://us9.campaign-archive2.com/?u=a18c518cc0e8c7e5625e6aa9b&id=156c330215&e=[UNIQID]" target="_blank">April</a>
<br />
<a href="http://us9.campaign-archive2.com/?u=a18c518cc0e8c7e5625e6aa9b&id=b77ae88bb9&e=d9e87269e3" target="_blank">May</a>
<br />
<a href="http://us9.campaign-archive1.com/?u=a18c518cc0e8c7e5625e6aa9b&id=20d3f7c3a9&e=d9e87269e3" target="_blank">June</a>
<br />
<a href="http://us9.campaign-archive1.com/?u=a18c518cc0e8c7e5625e6aa9b&id=3dfbef6096&e=d9e87269e3" target="_blank">July</a>
<br />
<a href="http://us9.campaign-archive1.com/?u=a18c518cc0e8c7e5625e6aa9b&id=f6a8082366&e=[UNIQID]" target="_blank">August</a>
<br />
<a href="http://us9.campaign-archive1.com/?u=a18c518cc0e8c7e5625e6aa9b&id=b2f422decf&e=9473265653">September</a>
<br />
<a href="http://eepurl.com/clS02n">October</a>
<br />
<a href="http://eepurl.com/cqvvTL">November</a>
<br />
<a href="http://eepurl.com/cvmudj">December</a>
<br />
</blockquote>

<h2>2015</h2>
<blockquote>
<a href="http://us9.campaign-archive2.com/?u=a18c518cc0e8c7e5625e6aa9b&id=261896af82&e=[UNIQID]" target="_blank">January</a>
<br />
<a href="http://us9.campaign-archive2.com/?u=a18c518cc0e8c7e5625e6aa9b&id=27fac32b30&e=[UNIQID]" target="_blank">February</a>
<br />
<a href="http://us9.campaign-archive2.com/?u=a18c518cc0e8c7e5625e6aa9b&id=2d8489ee55&e=[UNIQID]" target="_blank">March</a>
<br />
<a href="http://us9.campaign-archive1.com/?u=a18c518cc0e8c7e5625e6aa9b&id=40e4ae0ceb&e=[UNIQID]" target="_blank">April</a>
<br />
<a href="http://eepurl.com/bnUrJ1" target="_blank">May</a>
<br />
<a href="http://us9.campaign-archive1.com/?u=a18c518cc0e8c7e5625e6aa9b&id=0959ec23d7&e=[UNIQID]" target="_blank">June</a>
<br />
<a href="http://us9.campaign-archive2.com/?u=a18c518cc0e8c7e5625e6aa9b&id=345a0686b3&e=[UNIQID]" target="_blank">July</a>
<br />
<a href="http://us9.campaign-archive2.com/?u=a18c518cc0e8c7e5625e6aa9b&id=9d59e2154a&e=[UNIQID]" target="_blank">August & September</a>
<br />
<a href="http://us9.campaign-archive2.com/?u=a18c518cc0e8c7e5625e6aa9b&id=77905da884&e=[UNIQID]" target="_blank">October & November</a>
<br />
<a href="http://us9.campaign-archive1.com/?u=a18c518cc0e8c7e5625e6aa9b&id=b7ccbaf549&e=[UNIQID]" target="_blank">December</a></br>
</blockquote>


</div> </div>
 <!-- end #mainContent -->
  
 <br class="clearfloat" />
</div>
<!--<div id="footer">
<div style="float:right; width:170;"><a href="http://www.gleanweb.org" target="_blank"><img src="images/Nav buttons/gleanweb.png" alt="Website by GleanWeb" height="20" /></a></div>
<div style="width:700; "><center>Copyright © 2020 GleanSLO</center></div>
</div>-->
<div id="footer">
<div style="float:right; width:25%;text-align:right;"><a href="http://www.gleanweb.org" target="_blank"><img src="images/Nav buttons/gleanweb.png" alt="Website by GleanWeb" style="max-height:20px;" /></a></div>
<div style="float:right;width:35%;text-align:center;" id="google_translate_element"></div>
<script type="text/javascript">
function googleTranslateElementInit() { new google.translate.TranslateElement({pageLanguage: 'en', includedLanguages: 'es,en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element'); }
</script>
<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
<div style="width:39%; "><center>Copyright © 2020 GleanSLO</center></div>
</div>
<!-- end #container -->
 <br class="clearfloat" />
</div>
</body>
</html>
