<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>For Farmers</title>
<link href="gleanslo.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
-->
</style>
</head>
<body class="SH">
<div id="container">
  <div id="header">
   <img src="images/banners/logobanner1.png" width="876" height="180" border="2" /> 
  </div>
 <div class="navdiv">
    <div class="navigation">
        <div class="spacer">&nbsp;</div>
        <ul>
            <li><a href="index.php"><strong>Home</strong></a></li>
        <li><a><label class="lab" for="tog1">About</label></a>
				<input type="checkbox" id="tog1"/>
                <ul class="dropped" id="menu1">
                <li><a href="mission.php">Mission&nbsp;&&nbsp;vision</a></li>
                <li><a href="team.php">Our&nbsp;team</a></li>
                <li><a href="history.php">History</a></li>
                <li><a href="how.php">How&nbsp;it&nbsp;works</a></li>
                <li><a href="annual.php">What&nbsp;we've&nbsp;done</a></li>
                <li><a href="FAQ.php">FAQ</a></li>
                <li><a href="contact.php">Contact&nbsp;us</a></li>
                <li><a href="employment.php">Employment</a></li>
                </ul>
            </li>
            <li><a href="volunteer.php"><strong>Volunteer</strong></a></li>
            <li><a href="site_registration.php"><strong>Donate&nbsp;crop</strong></a></li>
        <li><a><label class="lab" for="tog2">Support</label></a>
				<input type="checkbox" id="tog2"/>
                <ul class="dropped" id="menu2">
                <li><a href="https://domains.giveffect.com/campaigns/10230-gleanslo" target="_blank">Donate</a></li>
                <li><a href="wish.php">Wish&nbsp;list</a></li>
                <li><a href="supporters.php">Supporters</a></li>
                <li><a href="sponsorship.php">Sponsorship</a></li>
                <li><a href="vehicle.php">Donate a vehicle</a></li>
                </ul>
             </li>
            <li><a href="harvestlist.php"><strong>Harvests</strong></a></li>
        </ul>
        </div>
        </div>
<div class="clearfloat"></div>
<div id="mainContent">
<div id="narrowbody">
<p><img src="images/logos/logo-small.png" width="230"/></p>
<div style="width:60%;float:right;"><img src="images/FarmersAndGrowersPage.jpg" style="width:450px;float:right; border:2px solid black; margin:10px;"/></div>
<div style="width:40%;">
<p>&nbsp;</p>
 <h3>For Farmers and Growers</h3>
<p>GleanSLO is a program of the Food  Bank Coalition of San Luis Obispo County that harvests excess produce and  donates it to local Food Bank agencies to be distributed to food insecure  individuals around the county. </p>
</div>
<br class="clearfloat" />
 <p><strong>We harvest:</strong></p>
 <div style="width:350px;float:right;"><a href="site_registration.php"><img src="images/Nav buttons/DonateCrop.png" style="width:200px;"/></a></div>
 <div>
 <ul><li>Quality produce that is no longer  commercially viable</li>
<li> Weather damaged crops</li>
<li>Produce from bypassed fields</li>
<li>Non-machine harvestable crops</li>
<li>Pollinator trees</li>
<li>Secondary growth</li>
</ul>
</div>
<p>Additionally, GleanSLO will pick  up crops which have already been harvested. Bins to pick into are available  upon request.</p>
<p>From small scale farms to large  grower cooperatives, GleanSLO has the capacity to harvest any size farm.</p>
<p>&ldquo;Talley Farms and our Fresh Harvest CSA program support  the work of GleanSLO as they provide fresh fruits and vegetables for the needy  in our community while educating on the importance of eating healthy.  We are grateful for the work of the GleanSLO  volunteers who harvest our &ldquo;imperfect&rdquo; produce that we would otherwise  cultivate back into the soil.&rdquo;<br />
  ~Andrea Chavez, Manager Fresh Harvest, 
  Talley Farms</p>
<strong>Protection:</strong>
<p>We properly train, supervise and  hold liability coverage for all volunteers who glean with us. We are happy to  provide a certificate of coverage if necessary.</p>
<p><strong>Benefits:</strong><br />
  </p>
<p>New  CA legislation that takes effect on January 1, 2017 will provide a tax credit  for all CA grown produce donated to food banks, <strong>equaling 15% of the donation&rsquo;s wholesale value</strong> (up from current expiring legislation which provides 10% of the donation&rsquo;s  inventoried value).&nbsp; Additionally, farmers are also eligible for a federal  tax deduction for donated produce. For information, see the link &nbsp;below.&nbsp; Please consult your tax advisor to determine your  eligibility for the tax incentives.</p>
<p><a href="http://gleanslo.org/documents/CAFB%20Food%20Donation%20Tax%20Benefit%20Overview.pdf" target="_blank">Summary of Federal and California produce donation tax  incentives</a></p>
<p><a href="https://www.ftb.ca.gov/forms/2018/18_3814.pdf" target="_blank">2018 CALIFORNIA TAX  CREDIT FORM for produce donations</a><br />
  <br />
  <a href="https://www.irs.gov/pub/irs-pdf/f8283.pdf" target="_blank">FEDERAL TAX  DEDUCTION FORM for produce donations</a></p>
<p>For more  information, contact Roxanne Sanders at&nbsp;<a href="mailto:gleanslo@slofoodbank.org">gleanslo@slofoodbank.org</a></p>
<p><a href="http://www.gpo.gov/fdsys/pkg/PLAW-104publ210/pdf/PLAW-104publ210.pdf"><strong>Federal Bill Emerson  Good Samaritan Food Donation Act</strong></a> - In 1996, President  Clinton signed this act to encourage donation of food and grocery products to  non-profit organizations for distribution to individuals in need. This law:</p>
<ul>
  <li>Protects you from liability when you donate  to a non-profit organization;</li>
  <li>Protects you from civil and criminal  liability should the product donated in good faith later cause harm to the  recipient;</li>
  <li>Standardizes donor liability exposure. You or  your legal counsel do not need to investigate liability laws in 50 states; and</li>
  <li>Sets a floor of &quot;gross negligence&quot;  or intentional misconduct for persons who donate grocery products. According to  the new law, gross negligence is defined as &quot;voluntary and conscious  conduct by a person with knowledge (at the time of conduct) that the conduct is  likely to be harmful to the health or well-being of another person.&quot;</li>
  <li>Protects you from liability when you donate to a non-profit organization; 
   <li>Protects you from civil and criminal liability should the product donated in good faith later cause harm to the recipient;</li>
  <li>Standardizes donor liability exposure. You or your legal counsel do not need to investigate liability laws in 50 states; and
    Sets a floor of &quot;gross negligence&quot; or intentional misconduct for persons who donate grocery products.  According to the new law, gross negligence is defined as &quot;voluntary and conscious conduct by a person with knowledge (at the time of conduct) that the conductis likely to be harmful to the health or well-being of another person.&quot;
    
  </li>
</ul>
<p>For more information:  <a href="http://feedingamerica.org/get-involved/corporate-opportunities/become-a-partner/become-a-product-partner/protecting-our-food-partners.aspx">Feeding America</a>.</p>
 <p>&nbsp;</p>
</div>
 
 <!-- end #mainContent --></div>
<!-- This clearing element should immediately follow the #mainContent div in order to force the #container div to contain all child floats --><br class="clearfloat" />
<!--<div id="footer">
<div style="float:right; width:170;"><a href="http://www.gleanweb.org" target="_blank"><img src="images/Nav buttons/gleanweb.png" alt="Website by GleanWeb" height="20" /></a></div>
<div style="width:700; "><center>Copyright © 2020 GleanSLO</center></div>
</div>-->
<div id="footer">
<div style="float:right; width:25%;text-align:right;"><a href="http://www.gleanweb.org" target="_blank"><img src="images/Nav buttons/gleanweb.png" alt="Website by GleanWeb" style="max-height:20px;" /></a></div>
<div style="float:right;width:35%;text-align:center;" id="google_translate_element"></div>
<script type="text/javascript">
function googleTranslateElementInit() { new google.translate.TranslateElement({pageLanguage: 'en', includedLanguages: 'es,en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element'); }
</script>
<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
<div style="width:39%; "><center>Copyright © 2020 GleanSLO</center></div>
</div>
<!-- end #container --></div>
</body>
</html>
