<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Supporters</title>
<link href="gleanslo.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
-->
</style>
</head>
<body class="SH">
<div id="container">
  <div id="header">
<img src="images/banners/logobanner1.png" width="876" height="180" border="2" /> 
  </div>
 <div class="navdiv">
    <div class="navigation">
        <div class="spacer">&nbsp;</div>
        <ul>
            <li><a href="index.php"><strong>Home</strong></a></li>
        <li><a><label class="lab" for="tog1">About</label></a>
				<input type="checkbox" id="tog1"/>
                <ul class="dropped" id="menu1">
                <li><a href="mission.php">Mission&nbsp;&&nbsp;vision</a></li>
                <li><a href="team.php">Our&nbsp;team</a></li>
                <li><a href="history.php">History</a></li>
                <li><a href="how.php">How&nbsp;it&nbsp;works</a></li>
                <li><a href="annual.php">What&nbsp;we've&nbsp;done</a></li>
                <li><a href="FAQ.php">FAQ</a></li>
                <li><a href="contact.php">Contact&nbsp;us</a></li>
                <li><a href="employment.php">Employment</a></li>
                </ul>
            </li>
            <li><a href="volunteer.php"><strong>Volunteer</strong></a></li>
            <li><a href="site_registration.php"><strong>Donate&nbsp;crop</strong></a></li>
        <li><a><label class="lab" for="tog2">Support</label></a>
				<input type="checkbox" id="tog2"/>
                <ul class="dropped" id="menu2">
                <li><a href="https://domains.giveffect.com/campaigns/10230-gleanslo" target="_blank">Donate</a></li>
                <li><a href="wish.php">Wish&nbsp;list</a></li>
                <li><a href="supporters.php">Supporters</a></li>
                <li><a href="sponsorship.php">Sponsorship</a></li>
                <li><a href="vehicle.php">Donate a vehicle</a></li>
                </ul>
             </li>
            <li><a href="harvestlist.php"><strong>Harvests</strong></a></li>
        </ul>
        </div>
        </div>
<div class="clearfloat"></div>
<div id="mainContent">
 <div id="narrowbody">
 <p><img src="images/logos/logo-small.png" width="230"/></p>
<p><strong>GleanSLO is grateful to the following  businesses and organizations for their financial support:</strong></p>
<div id="about" style="float:right;width:35%;">
<br />
<div style="text-align:center;"><a href="http://www.slofoodbank.org/gleanslo_donation.php" target="_blank"><img src="images/Nav buttons/donate-larger-green.png"  style="box-shadow:none;max-height:42px;" border="0" align="center" /></a></div>
<br /><br /><br />
<img src="images/photos/supporters1.jpg" style="width:95%;" title="Photo credit: Carolyn Eicher" /><br /><br /><br />
<img src="images/photos/supporters2.jpg" style="width:95%;" title="Photo credit: Carolyn Eicher"/><br /><br /><br />
<img src="images/photos/supporters3.jpg" style="width:95%;" title="Photo credit: Carolyn Eicher"/>
</div>

<p>
Avalon Foundation - Templeton<br />
<a href="http://www.acijet.com">Aviation Consultants Inc.</a><br />
<a href="http://www.blctempleton.org/">Templeton Bethel Evangelical Lutheran Church</a><br />
<a href="http://www.californiafreshmarket.com//m">California Fresh Markets</a><br />
Dimes Media<br />
<a href="http://www.darden.com/commitment/community.asp">Darden Restaurants, Inc. Foundation</a><br  />
<a href="http://enviromgmtinc.com">Enviro Management Inc.</a><br />
<a href="https://www.etnainteractive.com">Etna Interactive</span></a><br />
<a href="http://corporate.exxonmobil.com/">Exxon Mobil Foundation</span></a><br />
<a href="http://gerbersautoservices.com">Gerber's Auto Services</a><br />
<a href="http://www.ninerwine.com">Niner Wine Estates</a><br />
ORCA Free Inc.<br />
<a href="http://www.promega.com">Promega Bio Sciences, LLC</a><br />
<a href=" https://www.rabobankamerica.com/">Rabobank, N. A.</a><br />
<a href="http://www.slonewcomers.org/SLO_Newcomers/Welcome.html">San Luis Obispo Newcomers</span></a><br />
<a href="https://plus.google.com/109345770708210822268/about?gl=us&hl=en">San Luis Obispo Seventh Day Adventist Church</a><br />
<a href="http://www.sloumc.com">San Luis Obispo United Methodist Church</span></a><br />
<a href="http://www.specialtyconstruction.com">Specialty Construction, Inc.</span></a><br />
<a href="https://www.umpquabank.com">Umpqua Bank</a><br />
<a href="http://sanluisobispounitarianuniversalists.org">Unitarian Universalist Fellowship of SLO County</a><br />
<a href="http://www.winewavesandbeyond.com/">Wine Waves and Beyond</span></a><br />
</p>

<p><strong>Special thanks to our generous farmers, growers and donors! </strong></p>

<br />
<strong>2016 Donors:</strong>
<br/>
<br/>
Adele Anderson<br />
Antoon Family<br />
<a href="http://www.avilaandsonsfarms.com/Home_Page.html/">Avila & Sons Farms</a><br />
Baker Family<br />
Georgia Barr<br />
Jamie Basinger<br />
Bautista Farms<br />
Becker Family<br />
<a href="http://www.bejoseeds.com/usa/about-us/quick-profile.aspx">Bejo Seeds</a><br />
Bellevue-Santa Fe Charter School<br />
Beltran Family<br />
Bishop's Peak Elementary<br />
<a href="http://branchmillorganics.com/">Branch Mill Organic Farm</a><br />
Brauninger Family<br />
Bryant Family<br />
<a href="http://aeps.calpoly.edu/">Cal Poly Horticulture & Crops Science Unit</a><br />
Cal Poly Organic Farm<br />
Marge & Roger Castle<br />
Marna Christopher<br />
Cirone Family<br />
<a href="http://centralcoastgrown.org/"> City Farm-Central Coast Grown </a><br />
Collins Family<br />
David and Peggy Coon<br />
Lynne Cornell<br />
Cortez Farms<br />
Crowfoot Family<br />
Cundiff Family<br />
Dalessio Family<br />
Dana Creek Homeowners Association<br />
Ron and Louise Dawson<br />
Dente Family<br />
Detz Family<br />
Paulette Diaz<br />
Joel Diringer<br />
Jason Dornish<br />
Dragon Springs Farm<br />
<a href="http://duncanfamilyfarms.com/"> Duncan Family Farms </a><br />
Nancy and Tom Dwyer<br />
Creekside Avocados<br />
Chumash Village Mobile Home Park<br />
Evenson Family<br />
Gary Faucette<br />
<a href="http://www.firstfruitsslo.org/">Firstfruits Farm</a><br />
Kathy Foster<br />
Four Seasons Harvesting Inc.<br />
Pete Freitas<br />
Burt Fugate<br />
Larry Gabrisch<br />
Greenbase Antiques<br />
Gulino Family<br />
Harlow Family Orchard<br />
The Hasson Family<br />
<a href="http://hearstcastle.org/">Hearst Castle </a><br />
Leah Hencier<br />
Lupe Hernandez<br />
Bill Hidgon<br />
Norma Hoffman<br />
Simon Holland<br />
Horwitz Family<br />
Hunt Family Farms<br />
Ikeda Brothers<br />
Island Farms<br />
Douglas and Deborah Johnson<br />
Liz Johnston<br />
Susan Jonas<br />
Kapana Farms<br />
Kinney Family<br />
Sarah Krueckel<br />
Katie Krupp<br />
<a href="http://smithgroves.com/">L & C Smith Groves</a><br />
CA Natural Sweet Corn<br />
Marsha Lucero<br />
Trenton Luis<br />
Andrew Lunny<br />
Madansky Family<br />
Linda Mahnken<br />
<a href="http://www.mallardlakeranch.com/">Mallard Lake Ranch</a><br />
Adam Dale<br />
Master Gardeners Demo Garden<br />
McCall Farm<br />
Rob Mcdonald<br />
Bridget Mcgovern<br />
Milburn Family<br />
Moran Family<br />
Linda Mulvey<br />
Munak Ranch<br />
Pat and Tom Muran<br />
Merri Nagano<br />
Nichols Family<br />
Norris Family<br />
Our Global Family Farm<br />
Terry Parry<br />
Rosalyn Parsons<br />
Pechmann family<br />
Scott & Susan Pigeon<br />
The Plakias Family<br />
Rancho San Miguel Hills<br />
Ruth Reasor<br />
Red Barn Farms<br />
Brenda Reynolds<br />
<a href="http://www.robinsongfarms.com/">RobinSong Farms</a><br />
Steve & Mary Lou Ross<br />
Lauren Rueda and Reese Galido<br />
<a href="http://www.rutizfarms.com/">Rutiz Farms</a><br />
Jackie Santoro<br />
Peggy Sharpe<br />
Kathy Sherman<br />
Donna Silva<br />
<a href="http://slocreekfarms.com/index.html">SLO Creek Farms</a><br />
Thursday SLO Farmers Market<br />
<a href="http://sloveg.com/">SLO Veg</a><br />
Jacqueline and Michael Solomon<br />
Stanier Family<br />
Jiordana Stark<br />
Bernard & Joan Suttle<br />
Robert and Vicki Swett<br />
<a href="http://talleyfarms.com/">Talley Farms</a><br />
Saturday Templeton Farmers Market<br />
Stephanie Ricceri - Tierra Nueva Cohousing Homeowners Association<br />
The Tomsens<br />
<a href="http://www.trabiafarmsinc.com/">Trabia Farms</a><br />
Darlene Tunney Rosene<br />
Keith Silva<br />
Wagner Family<br />
Mary Wainscott<br />
Ken & Ebbie Ward<br />
Doug Wiggin<br />
Frankie Williams<br />
Sally Woelper<br />
<a href="http://www.wolffvineyards.com/">Wolff Vineyards</a><br />
<br />
</p>
<p><strong>These donors make GleanSLO’s work possible! You can use your purchasing power to show your support! An up-to-date monthly list of donating growers is included in our <a href="http://www.gleanslo.org/newsletter.php">monthly newsletter</a>. </strong><br />
<br />
<p>If you have made a donation and would like to be added this list, please contact Program Manager, Roxanne Sanders at 805-835-3750 or gleanslo@slofoodbank.org</p>
</div>
<p><br />
</p>
 <!-- end #mainContent -->
   
</div>
<!-- This clearing element should immediately follow the #mainContent div in order to force the #container div to contain all child floats --><br class="clearfloat" />
<!--<div id="footer">
<div style="float:right; width:170;"><a href="http://www.gleanweb.org" target="_blank"><img src="images/Nav buttons/gleanweb.png" alt="Website by GleanWeb" height="20" /></a></div>
<div style="width:700; "><center>Copyright © 2020 GleanSLO</center></div>
</div>-->
<div id="footer">
<div style="float:right; width:25%;text-align:right;"><a href="http://www.gleanweb.org" target="_blank"><img src="images/Nav buttons/gleanweb.png" alt="Website by GleanWeb" style="max-height:20px;" /></a></div>
<div style="float:right;width:35%;text-align:center;" id="google_translate_element"></div>
<script type="text/javascript">
function googleTranslateElementInit() { new google.translate.TranslateElement({pageLanguage: 'en', includedLanguages: 'es,en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element'); }
</script>
<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
<div style="width:39%; "><center>Copyright © 2020 GleanSLO</center></div>
</div>
<!-- end #container --></div>
</body>
</html>
