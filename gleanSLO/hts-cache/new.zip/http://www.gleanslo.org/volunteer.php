<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Volunteers Information</title>
<style type="text/css">
<!--
@import url("gleanslo.css");
-->
</style>
</head>
<body class="SH">
<div id="container">
<div id="header">
<img src="images/banners/Jahan.jpg" width="876" height="180" border="2" />
</div>
<div class="navdiv">
    <div class="navigation">
        <div class="spacer">&nbsp;</div>
        <ul>
            <li><a href="index.php"><strong>Home</strong></a></li>
        <li><a><label class="lab" for="tog1">About</label></a>
				<input type="checkbox" id="tog1"/>
                <ul class="dropped" id="menu1">
                <li><a href="mission.php">Mission&nbsp;&&nbsp;vision</a></li>
                <li><a href="team.php">Our&nbsp;team</a></li>
                <li><a href="history.php">History</a></li>
                <li><a href="how.php">How&nbsp;it&nbsp;works</a></li>
                <li><a href="annual.php">What&nbsp;we've&nbsp;done</a></li>
                <li><a href="FAQ.php">FAQ</a></li>
                <li><a href="contact.php">Contact&nbsp;us</a></li>
                <li><a href="employment.php">Employment</a></li>
                </ul>
            </li>
            <li><a href="volunteer.php"><strong>Volunteer</strong></a></li>
            <li><a href="site_registration.php"><strong>Donate&nbsp;crop</strong></a></li>
        <li><a><label class="lab" for="tog2">Support</label></a>
				<input type="checkbox" id="tog2"/>
                <ul class="dropped" id="menu2">
                <li><a href="https://domains.giveffect.com/campaigns/10230-gleanslo" target="_blank">Donate</a></li>
                <li><a href="wish.php">Wish&nbsp;list</a></li>
                <li><a href="supporters.php">Supporters</a></li>
                <li><a href="sponsorship.php">Sponsorship</a></li>
                <li><a href="vehicle.php">Donate a vehicle</a></li>
                </ul>
             </li>
            <li><a href="harvestlist.php"><strong>Harvests</strong></a></li>
        </ul>
        </div>
        </div>
<div class="clearfloat"></div>
<div id="mainContent">
<p><img src="images/logos/logo-small.png" width="230"/></p>
<h3>Ways to get involved...</h3>
<strong>Become a Gleaner</strong><br /><br />
<!--<div style="width:160px; float:left; margin:15px;"><a href="pickerinsert.php"><img src="images/Nav buttons/RegisterPicker.png"  onmouseover="this.src='images/Nav buttons/RegisterPicker2.png'" onmouseout="this.src='images/Nav buttons/RegisterPicker.png'" width="156" height="58" alt="register" /></a></div> -->
<div style="float:left; margin:15px;"><a class="button" style="width:150px; font-weight:bold;line-height:20px;"  href="pickerinsert.php">REGISTER TO<br />VOLUNTEER</a></div>
 The easiest way to get involved! Register as a volunteer and then sign  up for an event on our <a href="http://www.gleanslo.org/harvestlist.php">Harvests  page</a>. Gleans are seasonal, available all over SLO county, and last about  2 hours. Gleaners are the hands and heart of our efforts to rescue nature&rsquo;s  bounty for the benefit of our community!

<div id="about"><img style="float:right; width:200px;margin:10px;" src="images/photos/volunteerpage-1.jpg"/>
<p><strong>Harvest Leader</strong></p>
 <p>As a Harvest Leader, you will be trained and equipped to lead small groups of volunteers to harvest excess produce from homes in your area. Harvest Leaders drop off produce to a nearby food pantry, keeping the fruit as local as possible. Harvest Leaders may also co-lead farm gleans. It's up to each Harvest Leader to determine how frequently you would like to lead gleans. Harvest Leader Training occurs quarterly. GleanSLO T-shirt, equipment, harvest manual and additional supplies will be provided for each Harvest Leader. To learn more, contact Volunteer Coordinator,  Emily at <a href="mailto:ewilson@slofoodbank.org">ewilson@slofoodbank.org</a>.</p>
 <br class="clearfloat" />
 </div>
<br />
 <div id="about"><img style="float:right; width:200px;margin:10px;" src="images/photos/volunteerpage-2.jpg"/>
 <p><strong>Farmers&rsquo; Market Collection Leader</strong></p>
 <p>Want to get to know your local farmers AND help feed the hungry? Every week GleanSLO collects leftover produce from the SLO Thursday Night  and the Templeton Saturday Farmers&rsquo; Markets. Our Collection Leaders engage  with farmers, orchestrate volunteers and keep track of poundage and donation  receipts. To learn more, contact Volunteer Coordinator,  Emily at <a href="mailto:ewilson@slofoodbank.org">ewilson@slofoodbank.org</a>. </p>
 <br class="clearfloat" />
 </div>
 <br />
 <div id="about"><img style="float:right; width:200px;margin:10px;" src="images/photos/volunteerpage-4.jpg"/>
 <p><strong>Host a Fruit Drive</strong></p>
 <p>Host a Fruit Drive at  your school, business or neighborhood! The Fruit Drive model is similar to a  typical food drive, but the fruit being collected is gathered from trees,  rather than purchased. GleanSLO provides you with a Fruit Drive Kit that  includes the resources you&rsquo;ll need to successfully publicize and collect  hundreds of pounds of produce within yourS community.  Contact Program  Manager, Roxanne Sanders at <a href="mailto:gleanslo@slofoodbank.org">gleanslo@slofoodbank.org</a>, to learn more! </p>
 <br class="clearfloat" />
</div>
<br />
<div id="about"><img style="float:right; width:200px;margin:10px;" src="images/photos/volunteerpage-3.jpg"/>
 <p><strong>Group Volunteering</strong></p>
 <p>Does  your community group or volunteer organization want to participate in something  with an impact? Gleaning options that can accommodate large groups are limited,  seasonal and not guaranteed. Email Volunteer Coordinator,  Emily at <a href="mailto:ewilson@slofoodbank.org">ewilson@slofoodbank.org</a> and include the size of your group, potential dates and  times you are available, and any other considerations. </p>
 </div>
 <br />
 <br class="clearfloat" />
<div style="font-size:1.2em; text-align:center; font-weight:bold;">Returning volunteers</div>
  <table width="100%" cellspacing="6" cellpadding="10" align="center" >
    <tr>
      <td><a class="button" href="Pickers/NewPickers.php">Information</a></td>
      <td width="85%" align="left">Show the information for volunteers about how to participate.</td>
    </tr>
    <tr>
      <td><a class="button" href="Pickers/MyPage.php">My Page</a></td>
      <td align="left">Go to the My GleanSLO page. (You must first have given yourself a password using the Update button just below.)</td>
    </tr>
    <tr>
      <td><a class="button" href="Pickers/ContactUpdateLink.php">Update</a></td>
      <td align="left">Update my contact information or renew my registration.</td>
    </tr>
    <tr>
      <td><a class="button" href="Pickers/CurrentSignups.php">Signups</a></td>
      <td align="left">Resend the reminder email for harvests I am currently signed up for.</td>
    </tr>
     <tr>
      <td><a class="button" href="Pickers/AttendanceRequest.php">Attendance</a></td>
      <td align="left">Send my harvest attendance history by email.</td>
   </tr>
     <tr>
      <td><a class="button" href="Pickers/ParticipationTerms.php">Terms</a></td>
      <td align="left">Show me the Terms of Participation as a GleanSLO volunteer.</td>
   </tr>
  </table>
  <p>&nbsp;</p>
  <!-- end #mainContent -->
</div>
	<!-- This clearing element should immediately follow the #mainContent div in order to force the #container div to contain all child floats --><br class="clearfloat" />
   <!--<div id="footer">
<div style="float:right; width:170;"><a href="http://www.gleanweb.org" target="_blank"><img src="images/Nav buttons/gleanweb.png" alt="Website by GleanWeb" height="20" /></a></div>
<div style="width:700; "><center>Copyright © 2020 GleanSLO</center></div>
</div>-->
<div id="footer">
<div style="float:right; width:25%;text-align:right;"><a href="http://www.gleanweb.org" target="_blank"><img src="images/Nav buttons/gleanweb.png" alt="Website by GleanWeb" style="max-height:20px;" /></a></div>
<div style="float:right;width:35%;text-align:center;" id="google_translate_element"></div>
<script type="text/javascript">
function googleTranslateElementInit() { new google.translate.TranslateElement({pageLanguage: 'en', includedLanguages: 'es,en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element'); }
</script>
<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
<div style="width:39%; "><center>Copyright © 2020 GleanSLO</center></div>
</div>
<!-- end #container --></div>
</body>
</html>
