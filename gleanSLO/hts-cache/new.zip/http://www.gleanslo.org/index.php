<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="keywords" content="harvest, fruit, gleaning, gleaners, non-profit, food insecurity, pick" />
<title>GleanSLO</title>
<link href="gleanslo.css" rel="stylesheet" type="text/css" />
<style type="text/css">
@font-face {font-family: 'digital-7'; src: url(fonts/digital-7.ttf) }
  .counter {font-family: 'digital-7'; font-size: 18pt;font-weight:bold; color:white; background-color: #31318E;letter-spacing: 3px;
  border: 2px solid #9ECBD2;border-radius: 7px; line-height:20pt;}
#picture1 { position: relative;  left: 0px;  }
#picture2 { position: relative; left: -505px; }
#window {
	margin-left:10%;
	height: 87%;
	width: 86%;
	border: 1px solid #fff;
	overflow: hidden;
	position: relative;
	z-index: 2;
}
.fullj {
text-align:center;
font-weight:bold;
font-style:italic;
font-size: 1.3em;
}
.dbutton {
    display: block;
	 margin-left:5%;
	height:28px;width:85%; 
    font-weight:bold; font-family:Georgia, 'Times New Roman', Times, serif; font-size:125%; text-align:center;
	outline: none;
	cursor: pointer;
	color:#000000 !important;
    background-color:#faa83f; 
	text-align: center;
	text-decoration: none;
	padding: .5em 0em .55em;	
	-webkit-border-radius: .8em; 
	-moz-border-radius: .8em;
	border-radius: .8em;
}
.dbutton:link { color:#ffffff !important;}
.dbutton:visited {color:#ffffff !important;}
.dbutton:hover {  text-decoration: none !important;  color:#000000 !important;}
.dbutton:active {color:#862990 !important;	position: relative;	top: 2px;}

</style>
<script type="text/javascript">
var photoarray = new Array();
for (k=0 ; k<=11; k=k+1) {
	t=k+1;
	photoarray[k] = "images/slides/"+t+".jpg" }
</script>
<script type="text/javascript" src="includes/photoswap.js"></script> 
<meta name="google-translate-customization" content="363e6ccad3505032-f56cc7f01d3b0aee-gcdfbb9b7771c6948-10"></meta>
</head>

<body class="SH">
<div id="container">
<div id="header" style="border:none">
<a href="http://www.slofoodbank.org" target="_blank" style="outline:0" ><img src="images/banners/home2014.png" alt="SLO Food Bank" width="880" height="180"/></a>
</div>
 <div class="navdiv">
    <div class="navigation">
        <div class="spacer">&nbsp;</div>
        <ul>
            <li><a href="index.php"><strong>Home</strong></a></li>
        <li><a><label class="lab" for="tog1">About</label></a>
				<input type="checkbox" id="tog1"/>
                <ul class="dropped" id="menu1">
                <li><a href="mission.php">Mission&nbsp;&&nbsp;vision</a></li>
                <li><a href="team.php">Our&nbsp;team</a></li>
                <li><a href="history.php">History</a></li>
                <li><a href="how.php">How&nbsp;it&nbsp;works</a></li>
                <li><a href="annual.php">What&nbsp;we've&nbsp;done</a></li>
                <li><a href="FAQ.php">FAQ</a></li>
                <li><a href="contact.php">Contact&nbsp;us</a></li>
                <li><a href="employment.php">Employment</a></li>
                </ul>
            </li>
            <li><a href="volunteer.php"><strong>Volunteer</strong></a></li>
            <li><a href="site_registration.php"><strong>Donate&nbsp;crop</strong></a></li>
        <li><a><label class="lab" for="tog2">Support</label></a>
				<input type="checkbox" id="tog2"/>
                <ul class="dropped" id="menu2">
                <li><a href="https://domains.giveffect.com/campaigns/10230-gleanslo" target="_blank">Donate</a></li>
                <li><a href="wish.php">Wish&nbsp;list</a></li>
                <li><a href="supporters.php">Supporters</a></li>
                <li><a href="sponsorship.php">Sponsorship</a></li>
                <li><a href="vehicle.php">Donate a vehicle</a></li>
                </ul>
             </li>
            <li><a href="harvestlist.php"><strong>Harvests</strong></a></li>
        </ul>
        </div>
        </div>
<div class="clearfloat"></div>
<div id="sidebar1">
<br /><br />
  <div style="margin:auto;margin-bottom:20px;">
  <a href="https://www.flickr.com/photos/gleanslo/sets" target="_blank">
  <img src="images/Nav buttons/FlickrIcon.png"  style="height:35px;vertical-align:middle;" border="0"  title="Flickr"/></a>
  <a href="https://www.facebook.com/gleanslo?ref=hl" target="_blank">
  <img src="images/Nav buttons/FacebookIcon.png"  style="height:37px;vertical-align:middle;" border="0"  title="Facebook"/></a>

  <a href="http://gleanslo.org/WordPress/" target="_blank">
  <img src="images/Nav buttons/BlogIcon.png"  style="height:35px;vertical-align:middle;" border="0"  title="GleanSLO blog"/></a>
  <br />
<a href="https://www.instagram.com/gleanslo/" target="_blank">
  <img src="images/Nav buttons/Instagram.png"  style="height:37px;vertical-align:middle;" border="0"  title="Instagram"/></a>
<a href="https://www.youtube.com/channel/UCHKBhqwh4GsiRiFBxKF76sg" target="_blank">
  <img src="images/Nav buttons/youtube.png"  style="height:37px;vertical-align:middle;" border="0"  title="Youtube"/></a>
  </div>
  <div style=""><a class="dbutton" href="http://donate.slofoodbank.org/campaigns/10230-gleanslo" target="_blank">Donate</a></div>
<br />
<div  style="width:95%;font-size:16px; color:#000000;">
<br />
<form name="ccoptin" action="http://eepurl.com/-c44v" target="_blank" method="post" style="margin-bottom:2;">
<input type="submit" name="go" value="Join our newsletter" class="button" style="width:100%;font-size:10pt;font-weight:bold;">
</form>
</div>
<br />
  <ul id="flyout">
    <li><a class="button" style="width:78%; padding:10px 12px 0px 12px;" href="upcoming.php"><strong>Upcoming Events</strong></a></li>
    <li><a class="button" style="width:78%;  padding:10px 12px 0px 12px;"><label class="lab" for="tog3">News</label></a>
		<input type="checkbox" id="tog3"/>
    	<ul id="flown">
            <li><a class="button" style="width:150px; padding:10px 12px 0px 12px;" href="newsletter.php">Newsletter</a></li>
            <li><a class="button" style="width:150px; padding:10px 12px 0px 12px;" href="awards.php">Press</a></li>
            <li><a class="button" style="width:150px; padding:10px 12px 0px 12px;" href="WordPress/" target="_blank">Blog</a></li>
            <li><a class="button" style="width:150px; padding:10px 12px 0px 12px;" href="https://www.facebook.com/pages/GleanSLO/290283964316368" target="_blank">Facebook</a></li>
         </ul>
     </li>
    <li><a class="button" style="width:78%; padding:10px 12px 0px 12px;" href="farmers.php"><strong>For Farmers</strong></a></li>
    <li><a class="button" style="width:78%; padding:10px 12px 0px 12px;" href="photos.php"><strong>Photos &amp; Videos</strong></a></li>
    <li><a class="button" style="width:78%; padding:10px 12px 0px 12px;" href="resources.php"><strong>Resources</strong></a></li>
   <li><a class="button" style="width:78%; padding:10px 12px 0px 12px;" href="Utilities/PagesIndex.php"><strong>Administrative</strong></a></li>
  </ul>
  <br />
</div> <!-- end sidebar div -->
<div id="mainContent">
<div id="lefttext">
<br />
<div style="margin:auto; width:72%; text-align: center;"><span class="counter">&nbsp;1,776,248</span>&nbsp;pounds of fresh, local produce rescued from SLO County farms and backyards since 2010!</div>

<p class="fullj">Rescuing nature's bounty for the<br />
benefit of our community</p>  

<div id="window">
<table border="0px" cellpadding="0" cellspacing="0" align="center">
<tr bgcolor="#226"><td >
  <script>
      f('photoseq',photoarray,10,3000);
   </script></td></tr></table>
</div> 
  <!-- end #window -->
<br />
<br />
<div style="margin-left:10%;text-align:center; width:90%;">Through the act of harvesting and sharing food,  we connect and nourish our community to build stronger relationships and a  deeper appreciation for our food.</div>
<br />
<div style="background-color:#d4e0f2; text-align:center; padding:5px; width:50%px; margin-left:10%;"><strong>Glean</strong>: to harvest or collect leftover fruits and vegetables that would otherwise go to waste.</div>
<br /><br />
<br />
<br />
  
</div>
<!-- end #mainContent -->
</div>
<br class="clearfloat" />
<!--<div id="footer">
<div style="float:right; width:170;"><a href="http://www.gleanweb.org" target="_blank"><img src="images/Nav buttons/gleanweb.png" alt="Website by GleanWeb" height="20" /></a></div>
<div style="width:700; "><center>Copyright © 2020 GleanSLO</center></div>
</div>-->
<div id="footer">
<div style="float:right; width:25%;text-align:right;"><a href="http://www.gleanweb.org" target="_blank"><img src="images/Nav buttons/gleanweb.png" alt="Website by GleanWeb" style="max-height:20px;" /></a></div>
<div style="float:right;width:35%;text-align:center;" id="google_translate_element"></div>
<script type="text/javascript">
function googleTranslateElementInit() { new google.translate.TranslateElement({pageLanguage: 'en', includedLanguages: 'es,en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element'); }
</script>
<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
<div style="width:39%; "><center>Copyright © 2020 GleanSLO</center></div>
</div>
<!-- end #container --></div>
</body>
</html>
