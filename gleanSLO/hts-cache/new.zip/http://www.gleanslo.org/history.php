<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>History</title>
<link href="gleanslo.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
-->
</style>
</head>
<body class="SH">
<div id="container">
<div id="header">
<img src="images/banners/logobanner1.png" width="876" height="180" border="2" /> 
</div>
<div class="navdiv">
    <div class="navigation">
        <div class="spacer">&nbsp;</div>
        <ul>
            <li><a href="index.php"><strong>Home</strong></a></li>
        <li><a><label class="lab" for="tog1">About</label></a>
				<input type="checkbox" id="tog1"/>
                <ul class="dropped" id="menu1">
                <li><a href="mission.php">Mission&nbsp;&&nbsp;vision</a></li>
                <li><a href="team.php">Our&nbsp;team</a></li>
                <li><a href="history.php">History</a></li>
                <li><a href="how.php">How&nbsp;it&nbsp;works</a></li>
                <li><a href="annual.php">What&nbsp;we've&nbsp;done</a></li>
                <li><a href="FAQ.php">FAQ</a></li>
                <li><a href="contact.php">Contact&nbsp;us</a></li>
                <li><a href="employment.php">Employment</a></li>
                </ul>
            </li>
            <li><a href="volunteer.php"><strong>Volunteer</strong></a></li>
            <li><a href="site_registration.php"><strong>Donate&nbsp;crop</strong></a></li>
        <li><a><label class="lab" for="tog2">Support</label></a>
				<input type="checkbox" id="tog2"/>
                <ul class="dropped" id="menu2">
                <li><a href="https://domains.giveffect.com/campaigns/10230-gleanslo" target="_blank">Donate</a></li>
                <li><a href="wish.php">Wish&nbsp;list</a></li>
                <li><a href="supporters.php">Supporters</a></li>
                <li><a href="sponsorship.php">Sponsorship</a></li>
                <li><a href="vehicle.php">Donate a vehicle</a></li>
                </ul>
             </li>
            <li><a href="harvestlist.php"><strong>Harvests</strong></a></li>
        </ul>
        </div>
        </div>
<div class="clearfloat"></div>
<div id="mainContent">
 <div id="narrowbody">
<p><img src="images/logos/logo-small.png" width="230"/></p>
 <h3>What is our History?</h3>
  
 <span style="font-size:16px;"><span style="font-family:arial,helvetica,sans-serif;">In 2010, a group of inspired community members and individuals from non-profits in our county came together in conversation over a year’s time to talk about capturing excess produce that was grown in our county and sharing it locally with those in need. We gathered in cafes, homes, and meeting spaces hosted by Cal Poly’s SUSTAIN team while we brainstormed, researched, read, and talked over many cups of tea, coffee and snacks. </span></span></p>
		<p>
			<span style="font-size:16px;"><span style="font-family:arial,helvetica,sans-serif;">Together, we envisioned a community where neighbors shared their produce with each other, where people were not hungry, where there was abundance around and a feeling that we had enough. We looked at our world with connection, not isolation. We shared stories in person, in real time. We longed for opportunities to learn together ways that had been lost — togetherness over leisurely meals, over harvest, of skills that used to be common - the art of canning, tending to the earth, of multi-generations talking and being there for each other. We longed to share with each other stories about our lives. Stories about community. We envisioned connections forming with people over a backyard citrus tree, a large field or bountiful orchard — many people who wouldn’t otherwise have the chance to meet.</span></span></p>
		<p>
			<span style="font-size:16px;"><span style="font-family:arial,helvetica,sans-serif;">It is from this idea of togetherness, of helping each other, caring for our county, our planet, our community, that GleanSLO was born. In recognizing our history and accomplishments, there are many people we are grateful for who gathered around those tables and dedicated endless hours of visioning and brainstorming to make this happen. We won’t forget the grassroots way we started and the people who believed this was possible.</span></span></p>
		<p>
			<span style="font-size:16px;"><span style="font-family:arial,helvetica,sans-serif;"><strong>-Carolyn Eicher, GleanSLO co-founder</strong></span></span></p>
		<p>
			 </p>
			<strong><span style="font-size:16px;"><span style="font-family:arial,helvetica,sans-serif;"><u>2010</u></span></span></strong></p>
		<p style="margin-left:.5in;">
			<span style="font-size:16px;"><span style="font-family:arial,helvetica,sans-serif;">•    A few individuals from SLO Grown Kids start gleaning from local San Luis Obispo backyards in February 2010. The Backyard Harvest (BYH) Founder from Moscow, Idaho, Amy Grey, guides our work along with Paso Robles resident Gail McNichols who had started a local Paso Robles BYH chapter </span></span></p>
		<p style="margin-left:.5in;">
			<span style="font-size:16px;"><span style="font-family:arial,helvetica,sans-serif;">•    Cal Poly’s SUSTAIN team work with the new SLO Backyard Harvest to co-create the local gleaning initiative for San Luis Obispo county, hosting and leading the visioning meetings</span></span></p>
		<p style="margin-left:.5in;">
			<span style="font-size:16px;"><span style="font-family:arial,helvetica,sans-serif;">•    In Fall of 2010, a group of engaged individuals from various organizations meet monthly realizing that there is a shared vision and passion for establishing a county-wide gleaning effort </span></span></p>
		<p style="margin-left:.5in;">
			<span style="font-size:16px;"><span style="font-family:arial,helvetica,sans-serif;">•    Partners include the Food Bank Coalition of SLO County, Cal Poly's STRIDE, Cal Poly's SUSTAIN, Transition Towns, SLO Grown Kids, and One Cool Earth</span></span></p>
		<p style="margin-left:.5in;">
			<span style="font-size:16px;"><span style="font-family:arial,helvetica,sans-serif;">•    Poundage for the first year: 22,000; Volunteers: N/A; Employees: 0; Vehicles: 0</span></span></p>
		<p>
			<strong><span style="font-size:16px;"><span style="font-family:arial,helvetica,sans-serif;"><u>2011</u></span></span></strong></p>
		<p style="margin-left:.5in;">
			<span style="font-size:16px;"><span style="font-family:arial,helvetica,sans-serif;">•    In February 2011 "GleanSLO" is formed with the Food Bank taking a leadership role and facilitating gleans at larger farms, fields and orchards</span></span></p>
		<p style="margin-left:.5in;">
			<span style="font-size:16px;"><span style="font-family:arial,helvetica,sans-serif;">•    SLO Grown Kids hire designer, Marjorie Collins, to design the new GleanSLO logo</span></span></p>
		<p style="margin-left:.5in;">
			<span style="font-size:16px;"><span style="font-family:arial,helvetica,sans-serif;">•    United Way awards GleanSLO $5,000 for the Innovation Grant. Funds are matched by the Food Bank and Caroline Ginsberg is hired as the first GleanSLO employee through the AmeriCorps program from August 2011 through June 2012 </span></span></p>
		<p style="margin-left:.5in;">
			<span style="font-size:16px;"><span style="font-family:arial,helvetica,sans-serif;">•    Food Bank begins serving as the fiscal agency thanks to this grant opportunity</span></span></p>
		<p style="margin-left:.5in;">
			<span style="font-size:16px;"><span style="font-family:arial,helvetica,sans-serif;">•    Poundage: 37,988; Volunteers: N/A; Employees: 1 part time; Vehicles: 0</span></span></p>
		<p>
			<strong><span style="font-size:16px;"><span style="font-family:arial,helvetica,sans-serif;"><u>2012</u></span></span></strong></p>
		<p style="margin-left:.5in;">
			<span style="font-size:16px;"><span style="font-family:arial,helvetica,sans-serif;">•    Carolyn Eicher, co-founders of GleanSLO, becomes the Program Manager in June 2012 when Caroline Ginsberg leaves GleanSLO after finishing her AmeriCorps term</span></span></p>
		<p style="margin-left:.5in;">
			<span style="font-size:16px;"><span style="font-family:arial,helvetica,sans-serif;">•    Jeanine Lacore joins the team as the new AmeriCorps VIP member from August 2012-June 2013, and is hired on full-time by the Food Bank in July 2013 as the full-time Program Coordinator </span></span></p>
		<p style="margin-left:.5in;">
			<span style="font-size:16px;"><span style="font-family:arial,helvetica,sans-serif;">•    The first-ever Farmers’ Market Collection begins at the weekly Saturday Templeton Farmers’ Market in June with volunteer teams collecting excess produce that is taken back to the Paso Food Bank warehouse</span></span></p>
		<p style="margin-left:.5in;">
			<span style="font-size:16px;"><span style="font-family:arial,helvetica,sans-serif;">•  The Farmers' Market Collection Program expands to the Thursday San Luis Obispo downtown Farmers' Market in August of 2012, partnering with The Salvation Army to collect and distribute the produce</span></span></p>
		<p style="margin-left:.5in;">
			<span style="font-size:16px;"><span style="font-family:arial,helvetica,sans-serif;">•    Poundage: 99,165; Volunteers: N/A; Employees: 2 part-time; Vehicles: 0</span></span></p>
		<p>
			<strong><span style="font-size:16px;"><span style="font-family:arial,helvetica,sans-serif;"><u>2013</u></span></span></strong></p>
		<p style="margin-left:.5in;">
<span style="font-size:16px;"><span style="font-family:arial,helvetica,sans-serif;">•    In March, the updated website is launched thanks to the generosity of Dick Yates of Salem Harvest.  Features include online registration for crop donors and volunteer sign-ups for gleans, which increases the efficiency and quantity of gleans </span></span></p>
		<p style="margin-left:.5in;">
			<span style="font-size:16px;"><span style="font-family:arial,helvetica,sans-serif;">•    The community’s response to GleanSLO continues to blossom. The first City-wide Fruit Drive is held in San Luis Obispo in the spring collecting nearly 1,500 lbs of citrus</span></span></p>
		<p style="margin-left:.5in;">
			<span style="font-size:16px;"><span style="font-family:arial,helvetica,sans-serif;">•    A local family creates and funds the GleanSLO yard signs “My Garden Feeds Hungry Families” to thank homeowners donating produce and raise awareness about GleanSLO </span></span></p>
		<p style="margin-left:.5in;">
			<span style="font-size:16px;"><span style="font-family:arial,helvetica,sans-serif;">•    The first statewide Gleaning Conference is held in San Jose, which Jeanine Lacore and Carolyn Eicher attend</span></span></p>
		<p style="margin-left:.5in;">
			<span style="font-size:16px;"><span style="font-family:arial,helvetica,sans-serif;">•    In the fall, the Food Bank receives the USDA Community Food Project grant to build infrastructure and capacity of GleanSLO</span></span></p>
		<p style="margin-left:.5in;">
			<span style="font-size:16px;"><span style="font-family:arial,helvetica,sans-serif;">•    In September 2013, Carolyn Eicher passes the 'Program Manager' baton to Jen Miller as the title transitions to a full-time position</span></span></p>
		<p style="margin-left:.5in;">
			<span style="font-size:16px;"><span style="font-family:arial,helvetica,sans-serif;">•    Chuck Asmus is hired in November as a driver of GleanSLO’s grant-funded refrigerated box truck</span></span></p><p style="margin-left:.5in;">
                   <span style="font-size:16px;"><span style="font-family:arial,helvetica,sans-serif;">•    Jeanine Lacore and Jen Miller attend the SoCal Gleaning Conference hosted by Food Forward in Los Angeles</span></span></p><p style="margin-left:.5in;">
			<span style="font-size:16px;"><span style="font-family:arial,helvetica,sans-serif;">•    Poundage: 212,109; Volunteers: 401;  Farm Harvests: 85; Backyard Harvests: 152; Employees: 2 full-time, 1 part-time; Vehicles: 1 refrigerated box truck</span></span></p>
		<p>
			<strong><span style="font-size:16px;"><span style="font-family:arial,helvetica,sans-serif;"><u>2014</u></span></span></strong></p>
		<p style="margin-left:.5in;">
			<span style="font-size:16px;"><span style="font-family:arial,helvetica,sans-serif;">•    The first cohort of GleanSLO Neighborhood Harvest Leaders are trained to lead small gleans in their local cities.</span></span></p>
		<p style="margin-left:.5in;">
			<span style="font-size:16px;"><span style="font-family:arial,helvetica,sans-serif;">•    A replicable model for a student-led School Fruit Drive is developed and implemented in 7 schools in San Luis Obispo collecting nearly 2,000 pounds of fruit and raising awareness about food waste, hunger and sharing </span></span></p>
		<p style="margin-left:.5in;">
			<span style="font-size:16px;"><span style="font-family:arial,helvetica,sans-serif;">•    The Food Bank Nutrition Outreach Program and the UC Cooperative Extension use gleaned produce in cooking demonstrations at distribution sites to educate Food Bank recipients about nutritional value, recipes, and techniques for canning, freezing and dehydrating</span></span></p>
		<p style="margin-left:.5in;">
                       <span style="font-size:16px;"><span style="font-family:arial,helvetica,sans-serif;">•    Jen Miller and Jeanine Lacore attend Community Jam Gleaning Conference in Layfayette, CA hosted by The Urban Farmers and Village Harvest   </span></span></p>
		<p style="margin-left:.5in;">
			<span style="font-size:16px;"><span style="font-family:arial,helvetica,sans-serif;">•    More farmers begin working with GleanSLO, increasing the number of farm harvests by nearly 50% from 2013</span></span></p>
		<p style="margin-left:.5in;">
			<span style="font-size:16px;"><span style="font-family:arial,helvetica,sans-serif;">•    Poundage: 200,092; Volunteers: 572; Farm Harvests: 143; Backyard Harvests: 188; Employees: 2 full-time, 1 part time; Vehicles: 1 refrigerated box truck</span></span></p>

<p>
<strong><span style="font-size:16px;"><span style="font-family:arial,helvetica,sans-serif;"><u>2015</u></span></span></strong></p>
		<p style="margin-left:.5in;">
			<span style="font-size:16px;"><span style="font-family:arial,helvetica,sans-serif;">•    Susan Singley hired as GleanSLO Program Manager to replace Jen Miller, who was promoted to Director of Programs with the Food Bank</span></p>
		<p style="margin-left:.5in;">
			<span style="font-size:16px;"><span style="font-family:arial,helvetica,sans-serif;">•    Jeanine Lacore moves out of state and Josh Ayers is hired to fill the GleanSLO Program Coordinator position  </span></span></p>
		<p style="margin-left:.5in;">
			<span style="font-size:16px;"><span style="font-family:arial,helvetica,sans-serif;">•    GleanSLO partners with AmeriCorp and brings on AmeriCorp VIP Fellow Emily Wilson to focus on volunteer engagement and recruitment  </span></span></p>
		<p style="margin-left:.5in;">
                       <span style="font-size:16px;"><span style="font-family:arial,helvetica,sans-serif;">•   GleanSLO teams up with other gleaning organizations in Ventura and Santa Barbara Counties to have a joint gleaning day event called Glean805. Multiple gleaning events were scheduled across the Tri-County region. GleanSLO’s 60 volunteers at Talley Farms rescued almost 6,000 pounds of bell peppers   </span></span></p>
		<p style="margin-left:.5in;">
			<span style="font-size:16px;"><span style="font-family:arial,helvetica,sans-serif;">•   Susan Singley passes GleanSLO Program Manager baton on to Joshua Ayers   </span></span></p>
		<p style="margin-left:.5in;">
			<span style="font-size:16px;"><span style="font-family:arial,helvetica,sans-serif;">•    Poundage: 209,013; Volunteers: 545; Farm Harvests: 160; Backyard Harvests: 150; Employees: 2 full-time, 1 part time, 1 AmeriCorp Member; Vehicles: 1 refrigerated box truck </span></span></p>

<p>
<strong><span style="font-size:16px;"><span style="font-family:arial,helvetica,sans-serif;"><u>2016</u></span></span></strong></p>
		<p style="margin-left:.5in;">
			<span style="font-size:16px;"><span style="font-family:arial,helvetica,sans-serif;">•    Margaux Inman joins the GleanSLO team as Program Coordinator</span></p>
		<p style="margin-left:.5in;">
			<span style="font-size:16px;"><span style="font-family:arial,helvetica,sans-serif;">•    Emily Wilson attends Community Jam Gleaning Conference in Rohnert Park, CA hosted by Farm To Pantry, Petaluma Bounty, SONOMA Food Runners, Sonoma Valley Gleaning Project, and UC Cooperative Extension Sonoma County </span></span></p>
		<p style="margin-left:.5in;">
			<span style="font-size:16px;"><span style="font-family:arial,helvetica,sans-serif;">•    AmeriCorp VIP Fellow Emily Wilson fulfills her one year service as Volunteer Coordinator and Dylan Jones jumps in to fill her shoes
  </span></span></p>
		<p style="margin-left:.5in;">
                       <span style="font-size:16px;"><span style="font-family:arial,helvetica,sans-serif;">•   Josh Ayers passes the Program Manager baton to Roxanne Sanders
  </span></span></p>
		<p style="margin-left:.5in;">
			<span style="font-size:16px;"><span style="font-family:arial,helvetica,sans-serif;">•   We reach ONE MILLION POUNDS gleaned since our program’s inception!   </span></span></p>
		<p style="margin-left:.5in;">
			<span style="font-size:16px;"><span style="font-family:arial,helvetica,sans-serif;">•    Poundage: 239,389; Volunteers: 533; Farm Harvests: 194; Backyard Harvests: 208; Employees: 2 full-time, 1 part time, 1 AmeriCorp Member; Vehicles: 2 </span></span></p>

 </div>
 <!-- end #mainContent -->
  
 <br class="clearfloat" />
</div>
<!--<div id="footer">
<div style="float:right; width:170;"><a href="http://www.gleanweb.org" target="_blank"><img src="images/Nav buttons/gleanweb.png" alt="Website by GleanWeb" height="20" /></a></div>
<div style="width:700; "><center>Copyright © 2020 GleanSLO</center></div>
</div>-->
<div id="footer">
<div style="float:right; width:25%;text-align:right;"><a href="http://www.gleanweb.org" target="_blank"><img src="images/Nav buttons/gleanweb.png" alt="Website by GleanWeb" style="max-height:20px;" /></a></div>
<div style="float:right;width:35%;text-align:center;" id="google_translate_element"></div>
<script type="text/javascript">
function googleTranslateElementInit() { new google.translate.TranslateElement({pageLanguage: 'en', includedLanguages: 'es,en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element'); }
</script>
<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
<div style="width:39%; "><center>Copyright © 2020 GleanSLO</center></div>
</div>
<!-- end #container -->
 <br class="clearfloat" />
</div>
</body>
</html>
