<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>FAQ</title>
<link href="gleanslo.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
-->
</style>
</head>
<body class="SH">
<div id="container">
<div id="header">
<img src="images/banners/banner-1.jpg" width="876" height="180" border="2"/>
</div>
<div class="navdiv">
    <div class="navigation">
        <div class="spacer">&nbsp;</div>
        <ul>
            <li><a href="index.php"><strong>Home</strong></a></li>
        <li><a><label class="lab" for="tog1">About</label></a>
				<input type="checkbox" id="tog1"/>
                <ul class="dropped" id="menu1">
                <li><a href="mission.php">Mission&nbsp;&&nbsp;vision</a></li>
                <li><a href="team.php">Our&nbsp;team</a></li>
                <li><a href="history.php">History</a></li>
                <li><a href="how.php">How&nbsp;it&nbsp;works</a></li>
                <li><a href="annual.php">What&nbsp;we've&nbsp;done</a></li>
                <li><a href="FAQ.php">FAQ</a></li>
                <li><a href="contact.php">Contact&nbsp;us</a></li>
                <li><a href="employment.php">Employment</a></li>
                </ul>
            </li>
            <li><a href="volunteer.php"><strong>Volunteer</strong></a></li>
            <li><a href="site_registration.php"><strong>Donate&nbsp;crop</strong></a></li>
        <li><a><label class="lab" for="tog2">Support</label></a>
				<input type="checkbox" id="tog2"/>
                <ul class="dropped" id="menu2">
                <li><a href="https://domains.giveffect.com/campaigns/10230-gleanslo" target="_blank">Donate</a></li>
                <li><a href="wish.php">Wish&nbsp;list</a></li>
                <li><a href="supporters.php">Supporters</a></li>
                <li><a href="sponsorship.php">Sponsorship</a></li>
                <li><a href="vehicle.php">Donate a vehicle</a></li>
                </ul>
             </li>
            <li><a href="harvestlist.php"><strong>Harvests</strong></a></li>
        </ul>
        </div>
        </div>
<div class="clearfloat"></div>
<div id="mainContent">
 <div id="narrowbody">
<p><img src="images/logos/logo-small.png" width="230"/></p>
<h3>Frequently Asked Questions</h3>
<p><strong>Can I bring my friend?</strong></p>
<p>Yes! Just be sure that they have registered at  <a href="pickerinsert.php">this page</a>, and have signed up for the harvest along with you. We need to keep track of how many people are coming to each harvest so we don't have too many or too few volunteers.</p>
<p> <strong>Can I bring my kids?</strong></p>
<p><strong>All volunteers under 18 must be actively supervised by an adult who is on the roster.</strong></p>
<p>We believe that picking  with GleanSLO is a valuable educational experience and a fabulous opportunity for young folks to give back to the community.  When we  announce new harvests, we will call special attention to those that are suitable for kids.  Some of the farmers allow children on their property to help, others do not. If it's a kid-friendly harvest, we will indicate that on the Harvests calendar.</p>
<p>If your child is high school age or older, please register and sign them up as an adult. As the parent, you will check off the waiver form on their behalf when they sign up. Nobody under the age of 16 may climb a  ladder, and climbing trees is never allowed. If the lowest fruit is not reachable from the ground, there aren't many  opportunities for kids to help. We always provide as much information as possible about the height of the tree and the lowest fruit, so that you can  make the decision about whether or not to bring your kids.</p>
<p><strong>What should I bring?</strong></p>
<ul>
  <li>Bring a re-usable bag in case the farmer of  grower allows volunteers to take a portion of the produce home with you.</li>
  <li>Bring water to drink, and  please take care of any bathroom needs before arriving at the harvest  site. We will not have access to a  restroom.</li>
  <li>A ladder will be helpful  at many harvests. We always provide as much information as possible about the height  of the tree and the lowest fruit, so that you can make the decision whether or not you'd like to sign up. We will provide orchard ladders when it is useful, and ask only volunteers who are capable to use them. No one under 16 is permitted to  climb a ladder. </li>
  <li>You may want to bring  gloves for handling wooden ladders, or latex gloves for picking fruit.</li>
</ul>
  <p><strong>What should I wear?</strong></p>
  <ul>
    <li>Sunblock</li>
    <li>Long-sleeved T-shirt</li>
    <li>Long pants</li>
    <li>Comfortable closed-toe  shoes</li>
    <li>A hat (trees are often  dusty)</li>
    </ul>
    <p><strong>Has the fruit been sprayed with chemicals?</strong>
      
    </p>
    <p>Sometimes. Our harvests take place at a wide  variety of properties, from 10-acre orchards to urban backyards. We always ask the property owner whether or  not their fruit has been sprayed with non-organic chemicals in the last three  years, and we will report that information to you when we schedule the harvest.</p>
    <p><strong>I completed the Volunteer Registration Form. Am I signed up for the       harvest?</strong></p>
<p>Not yet. You have completed the first step of giving  us your contact information. Now you need to visit our <a href="harvestlist.php">harvests page</a>. Here you will find all of the open harvests that are currently scheduled. Sign up for the harvest  that you would like to attend. If there are no harvests listed, then we do not have any scheduled, or the scheduled harvests are already full. Check back frequently for new  postings.</p>
<p><strong>I signed up for a harvest. When will I get the address?</strong></p>
<ul>
  <li>After you sign up for a  harvest on the harvests page, your name is added to the harvest roster. The page that appears right after you sign up shows the address for the harvest. Write it down before you go to any other page.</li>
  <li>You will also be sent an email with a link to the harvest details.</li>
  <li>Make sure that we have  your contact information so we can put you on the harvest roster. If you have not previously registered as a volunteer, fill out the <a href="pickerinsert.php">Volunteer Registration Form</a>. You have to complete this form  only once.</li>
</ul>
  <p><strong>I signed up for a harvest, and now I can't go. What should I do?</strong>
    
  </p>
  <p>The email that you receive after signing up for the harvest has a link in it to use if you need to cancel. Cancelling gives someone else a chance to attend the harvest.  </p>
  <p><strong>Do I have to stay at the harvest for the entire time?</strong></p>
  <p>Since   most harvests are scheduled for only two hours, we ask that you sign up   only if you can arrive on time and stay for the whole harvest.<br />
  <br />
    <strong>Why are the harvests filling so quickly?</strong></p>
<p>Hundreds of registered volunteers are being  notified of a harvest.  We believe that it is most fair to notify all volunteers at the same time through  email when a large harvest is posted. Trying  to determine subgroups that should be notified first would create too  many complications.</p>
  <p><strong>Why are  there not more harvests?</strong></p>
  <p>GleanSLO relies on donations from crop owners. While  we do want crop owners to be aware of our service, we do not contact specific growers to ask them to donate. After a crop is donated, our leadership team  factors GleanSLO's ability to staff harvests, parking and the requests of  the land owner to determine how many harvests will be hosted. </p>
<p><strong>Who runs GleanSLO?</strong></p>
  <p>GleanSLO is a program of the Food Bank Coalition of San Luis Obispo County that unites farmers, community volunteers, backyard gardeners, health advocates and food providers to harvest and donate excess produce into our local food system. </p>
<p> </p> </div>
 <!-- end #mainContent -->
  
 <br class="clearfloat" />
</div>
<!--<div id="footer">
<div style="float:right; width:170;"><a href="http://www.gleanweb.org" target="_blank"><img src="images/Nav buttons/gleanweb.png" alt="Website by GleanWeb" height="20" /></a></div>
<div style="width:700; "><center>Copyright © 2020 GleanSLO</center></div>
</div>-->
<div id="footer">
<div style="float:right; width:25%;text-align:right;"><a href="http://www.gleanweb.org" target="_blank"><img src="images/Nav buttons/gleanweb.png" alt="Website by GleanWeb" style="max-height:20px;" /></a></div>
<div style="float:right;width:35%;text-align:center;" id="google_translate_element"></div>
<script type="text/javascript">
function googleTranslateElementInit() { new google.translate.TranslateElement({pageLanguage: 'en', includedLanguages: 'es,en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element'); }
</script>
<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
<div style="width:39%; "><center>Copyright © 2020 GleanSLO</center></div>
</div>
<!-- end #container -->
 <br class="clearfloat" />
</div>
</body>
</html>
