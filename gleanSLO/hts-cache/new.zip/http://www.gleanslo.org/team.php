<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Our Team</title>
<link href="gleanslo.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
-->
</style>
</head>
<body class="SH">
<div id="container">
<div id="header">
<img src="images/banners/logobanner1.png" width="876" height="180" border="2" /> 
</div>
<div class="navdiv">
    <div class="navigation">
        <div class="spacer">&nbsp;</div>
        <ul>
            <li><a href="index.php"><strong>Home</strong></a></li>
        <li><a><label class="lab" for="tog1">About</label></a>
				<input type="checkbox" id="tog1"/>
                <ul class="dropped" id="menu1">
                <li><a href="mission.php">Mission&nbsp;&&nbsp;vision</a></li>
                <li><a href="team.php">Our&nbsp;team</a></li>
                <li><a href="history.php">History</a></li>
                <li><a href="how.php">How&nbsp;it&nbsp;works</a></li>
                <li><a href="annual.php">What&nbsp;we've&nbsp;done</a></li>
                <li><a href="FAQ.php">FAQ</a></li>
                <li><a href="contact.php">Contact&nbsp;us</a></li>
                <li><a href="employment.php">Employment</a></li>
                </ul>
            </li>
            <li><a href="volunteer.php"><strong>Volunteer</strong></a></li>
            <li><a href="site_registration.php"><strong>Donate&nbsp;crop</strong></a></li>
        <li><a><label class="lab" for="tog2">Support</label></a>
				<input type="checkbox" id="tog2"/>
                <ul class="dropped" id="menu2">
                <li><a href="https://domains.giveffect.com/campaigns/10230-gleanslo" target="_blank">Donate</a></li>
                <li><a href="wish.php">Wish&nbsp;list</a></li>
                <li><a href="supporters.php">Supporters</a></li>
                <li><a href="sponsorship.php">Sponsorship</a></li>
                <li><a href="vehicle.php">Donate a vehicle</a></li>
                </ul>
             </li>
            <li><a href="harvestlist.php"><strong>Harvests</strong></a></li>
        </ul>
        </div>
        </div>
<div class="clearfloat"></div>
<!-- HI JEN MARGAUX AND ROXANNE! DON'T TAKE OUT THE <div id-"about"> TAG JUST BELOW OR THE </div> TAG AT THE END. THEY ADD THE DROP SHADOWS TO THE PHOTOS.-->
<h3>Our Team</h3>
<div id="about" style="margin-left:10px;margin-right:10px;">
<h3>Staff</h3>

<p><div style="width: 170px; float:left;"><img alt="Roxanne Sanders" src="http://www.gleanslo.org/images/about/RoxanneSanders.jpg" width="150" /></div>
<strong>Roxanne Sanders, GleanSLO Program Manager, Food Bank </strong>- Roxanne grew up in the Bay Area town of El Cerrito.  She developed a deep love of 'community’ while studying city planning at Sonoma State University. Her first taste of working in agriculture was with a non-profit farm in Petaluma, California, which provided free or low-cost produce to low-income families, as well as nutrition education.  In 2014, she moved to Templeton with her soon to be husband. Roxanne and her fiancé currently run a 2-acre organic farm as their “second job,” which is where her relationship with GleanSLO blossomed.  She loves being outside and spending time with her family. She spends most of her free time traveling up and down the coast with her fiancé and their two 85 pound labs!</p>
<br />
<br />
<div id="about">
<p><div style="width: 170px; float:left;"><img alt="Emily Wilson" src="http://www.gleanslo.org/images/about/EmilyWilson.jpg" width="150" /></div>
<p><strong>Emily Wilson, GleanSLO Program Coordinator</strong> - </p>
<p>Commonly known as Wilson or simply Willy, Emily Wilson  grew up in the suburbs of Cincinnati, Ohio. After spending four years in  Tallahassee, Florida earning her bachelors degree, she relocated to central  coast California where she discovered her passion for communal living,  mountainous landscapes, and rescuing fresh local produce. She spends her time  outside of GleanSLO cycling around town, playing games, cooking, or making  'art'. </p>
<br />
<br />
<br />
<div id="about">
<p><div style="width: 170px; float:left;"><img alt="Chuck Asmus" src="http://www.gleanslo.org/images/about/ChuckAsmus.jpg" width="150" /></div>
<p><strong>Chuck Asmus, GleanSLO Driver</strong> - </p>
<p>Chuck was raised in Southern California where he graduated high school. In Northern California, he earned a bachelor degree and teaching credential. For 33 1/2 years he worked as a clerk. Upon retirement he and his wife moved to the Central Coast. Chuck was recruited by legend recruiter and volunteer Marv to GleanSLO. After a year of volunteering with the non-profit, he was hired as part-time driver and facilitator by Jen Miller and has since been involved with GleanSLO through 6 directors and 1024 harvests.</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
</div>

<br />
<br />
<br />    
<div style="float:left;"><h3><strong>Steering Committee Team</strong></h3></div>
<br />
<br />
<br />
<br />
<div>
<p><div style="width: 170px; float:left;"><img alt="Ross Chenot" src="images/about/RossChenot.jpg" width="150" /></div>
<strong>Ross Chenot</strong> - Ross fills his retired life enjoying our wonderful outdoors.  Along with regular gleaning, he cycles, backpacks and rows.  He also volunteers as a tutor in Santa Maria. Retiring after 35 years in the religious non-profit world, Ross loves to help people struggling on the margins.  He regularly recruits friends and neighbors to join him in rescuing food from local farms and backyards.<br /><br /><br /><br /></p>
</div>
<br />
<br />
<div>
<p><div style="width: 170px; float:left;"><img alt="Susan McTaggart" src="images/about/SallyBrooks-Schulke.jpg" width="150" /></div>
<strong>Sally Brooks-Schulke</strong> - I worked for twenty years as a registered dietitian, and daily saw  the role of good nutrition in promoting health and&nbsp; fostering disease. I  then become a school teacher for 17 years; where&nbsp; my favorite position was  teaching hands on science lab to fourth, fifth and sixth graders. Students were  always amazed to understand that the human body is composed entirely from the  food they ate and water. I moved to California from Cambridge, Massachusetts just weeks  after I got married in 1980. I grew up in Connecticut and my family were avid  gardeners. I was thrilled to garden every day of the year here and have always  had fruit trees and a vegetable garden. Glean SLO's mission to provide high quality fruits and vegetables  to the 46,000 food insecure people in our county fits right in with my goals  for raising a healthy society.
</div>
<br />
<div>
<p><div style="width: 170px; float:left;"><img alt="Susan McTaggart" src="http://www.gleanslo.org/images/about/Susan-McTaggart.jpg" width="150" /></div>
<strong>Susan McTaggart. Los Osos Community Member</strong> - Susan first discovered the San Luis Obispo area when she came to Cal Poly in 1974.  After graduating with a BS in Natural Resources Management she moved to Washington state for ten years, returning to the central coast to raise her family.  She taught elementary school in Atascadero until retiring in 2014.  Being a long-time gardener and advocate for healthy eating, volunteering with GleanSLO was a perfect fit for her retirement time.  She loves being able to help others by spending time outdoors harvesting fresh produce.  She was immediately impressed by the sense of community and caring that GleanSLO and its volunteers represent, and is proud to be a part of this group.</p>
</div>
<br />
<br/>

<div>
<p><div style="width: 170px; float:left;"><img alt="Jennifer Codron" src="http://www.gleanslo.org/images/about/Jennifer-Codron.jpg" width="150" /></div>
<strong>Jennifer Codron, Director, SLO Grown Kids</strong> - Growing up in Michigan,  Jennifer feasted on produce from the garden during summertime.  She  attended Loyola University in Chicago where she earned a degree in Philosophy  with a minor in Environmental Science.  She has worked as a field  biologist and an arborist.  She currently volunteers as the Monarch Grove  Elementary School Garden Coordinator.  She is passionate about introducing  kids to the pleasures and benefits of eating fresh fruit and vegetables.</p>
</div>
<br />
<br />
<br />
<br />
<br/>
<div>
<p><div style="width: 170px; float:left;"><img alt="Carolyn Eicher" src="http://www.gleanslo.org/images/about/Carolyn-Eicher.jpg" width="150"/></div>
<strong>Carolyn Eicher, GleanSLO co-founder</strong> - Carolyn Eicher loves to connect people through food--gleaning and harvesting, cooking and gardening. She was former GleanSLO Program Manager and also co-founded SLO Grown Kids, a local non-profit, to help promote school gardens. She loves photography and over the years has provided many photos for GleanSLO's newsletters, blog, Facebook and Flickr. She is proud to have helped create this gleaning program and loves that friendships have formed in fields, orchards, backyards and farms.</p>
</div>
<br />
<br />
<br />
<br />
<div>
<p><div style="width: 170px; float:left;"><img alt="Kylee Singh" src="http://www.gleanslo.org/images/about/Kylee.jpg" width="150" /></div>
<strong>Kylee Singh, Los Osos Community Member- </strong>Kylee is from Brawley, California, a small farming community in the furthest southeast corner of the state. Her connection to the land was established early in her childhood when her favorite pastime was doing field checks with her dad and "sampling" produce before harvest. Since high school, Kylee has lived all over California but has most recently moved back to the central coast after three years spent in Alaska. Kylee has a degree in Environmental Science from Humboldt State University (HSU) and her Masters in Public Policy (MPP '13) from Cal Poly. In 2016, Kylee and her husband Nick were lucky enough to move back to SLO County so she could take the role as Cal Poly's first Sustainability Coordinator. Throughout school and before her job at Cal Poly she worked with a variety of environmental non-profits including ECOSLO here locally. While she feels blessed to have established a career in sustainability, specifically as it relates to the university's resource management, her passion has always been in sustainable food systems. Her role on the Glean SLO steering committee is one fun way to continue working toward a more socially and environmentally just food web. When she is not working or gleaning, you can find her and her husband working on their house, on an adventure in the great outdoors, or growing, cooking, and preserving local bounty. She loves sharing her foodie skills and the fruits of her labor with her friends, family, and community.</p>
</div>

<div>
<p><div style="width: 170px; float:left;"><img alt="Ann Ketelaar" src="http://www.gleanslo.org/images/about/AnnKetelaar.jpg" width="150" /></div>
<strong>Ann Ketelaar, Community member- </strong> Ann Ketelaar grew up in Southern California.  She moved to the Central Coast just over 20 years ago and loves it. She and her husband Dave raised their two teenage sons in Pismo Beach.  After she transitioned away from full time work as a CPA to focus on her family, she began gleaning in 2015 and has completed over 100 gleans serving as both a gleaner and a glean leader.  GleanSLO and the San Luis Obispo Food Bank allowed her to set an example for her family, showing them the importance of helping a worthy cause. Plants and gardening have always been an interest and hobby. Gleaning is a great opportunity to see firsthand what others have done with their gardens while helping people directly in our community.  It has been an incredibly rewarding opportunity to meet people from all backgrounds and ages.  In her spare time Ann also enjoys hiking with the family dog, rowing, doing Pilates and spending time with friends.
</p>
<br />
</div>

<div>
<p><div style="width: 170px; float:left;"><img alt="Nicholas Hustedt" src="http://www.gleanslo.org/images/about/NicholasHustedt.jpg" width="150" /></div>
<strong>Nicholas Hustedt, Community member- </strong>Nick is a lifelong Californian who grew up in the redwood forest in rural BoulderCreek near Santa Cruz. Nick and his wife Suzanne have two adult children, three grandchildren and live in Atascadero. Nick is a retired wildland firefighter with 38 years of experience with CalFire, US Forest Service and the Bureau of Land Management. In retirement Nick enjoys golf, traveling, outdoor activities and working in his wood shop. He and his wife Suzanne have been gleaning at the Templeton Farmers Market for the last 4 years. In addition to his work with GleanSLO Nick is a driver for Atascadero Loaves and Fishes. Nick is proud of his participation in providing nutritious resources for those in need.</p>
<br />
</div>
<div>
<p><div style="width: 170px; float:left;"><img alt="Suzanne Hustedt" src="http://www.gleanslo.org/images/about/SuzanneHustedt.jpg" width="150" /></div>
<strong>Suzanne Hustedt, Community member- </strong> When Suzanne discovered San Luis Obispo County after high school, she knew it was where she wanted to be, and has lived in the county since 1972. It was here that she raised her son and daughter, both of whom attended school in Atascadero. Suzanne has a grandson and granddaughter living in Atascadero, and a granddaughter in Glendale. In her career as an RN she has worked primarily as a Labor and Delivery and Newborn Care nurse, from the early 70’s until retirement in 2014. One of Suzanne’s joys is meeting parents with grown kids that remember her as their nurse from 20, 30 or 40 years ago. 
In Retirement Suzanne enjoys gardening and has worked with One Cool Earth in the San Gabriel school garden. Suzanne and her husband Nick have been involved with Glean SLO for the past four years, primarily with gleaning the Templeton Farmers Market. Other interests include making herbal concoctions, traveling, being with grandkids, pilates, reading and being in nature.</p>
</div>

<br />
<br />
<div style="float:left;">
<strong>Past Steering Committee Members, Founders and Contributors</strong>
<br />
<br />
Chris Aho
<br />
Bev Aho
<br />
Kathy apRoberts
<br />
Roger Burton
<br />
Megan Chicoine, Former Community Outreach Manager, Food Bank
<br />
Rob Coghill
<br />
Jim Cole
<br />
Norma Cole, Transition Towns, Institute for Sustainable Living
<br />
Lynn Cullen
<br />
Greg Ellis, One Cool Earth
<br />
Caroline Ginsberg
<br />
Carl R. Hansen, Food Bank Coalition CEO 
<br />
Lynn James
<br />
Gail McNichols
<br />
Jim Patterson
<br />
Dr. Liz Schlemer
<br />
Pam Stein
<br />
Stephanie Teaford, Community Liaison, STRIDE, Cal Poly, Board Member, Food Bank Coalition
<br />
Dr. Linda Vanasupa
<br />
Nell Wade
<br />
<br />
</div>
</div><!--<div id="footer">
<div style="float:right; width:170;"><a href="http://www.gleanweb.org" target="_blank"><img src="images/Nav buttons/gleanweb.png" alt="Website by GleanWeb" height="20" /></a></div>
<div style="width:700; "><center>Copyright © 2020 GleanSLO</center></div>
</div>-->
<div id="footer">
<div style="float:right; width:25%;text-align:right;"><a href="http://www.gleanweb.org" target="_blank"><img src="images/Nav buttons/gleanweb.png" alt="Website by GleanWeb" style="max-height:20px;" /></a></div>
<div style="float:right;width:35%;text-align:center;" id="google_translate_element"></div>
<script type="text/javascript">
function googleTranslateElementInit() { new google.translate.TranslateElement({pageLanguage: 'en', includedLanguages: 'es,en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element'); }
</script>
<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
<div style="width:39%; "><center>Copyright © 2020 GleanSLO</center></div>
</div>
<!-- end #container -->
 <br class="clearfloat" />
 </div>
</div>
</body>
</html>
